'use strict';
// Shared helpers for all pages.

window.SN = (() => {
  const $ = (s, el = document) => el.querySelector(s);
  const KEYS = 'streamnet.keys';
  const LOOK_KEY = 'streamnet.look';

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      method: opts.method || 'GET',
      headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed (' + res.status + ')');
    return data;
  }

  // server clock, so countdowns agree between viewers
  let skew = 0;
  const now = () => Date.now() + skew;

  let cfg;
  async function config() {
    if (!cfg) {
      cfg = await api('/api/config');
      skew = cfg.serverTime - Date.now();
    }
    return cfg;
  }

  function toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }

  const keys = () => {
    try { return JSON.parse(localStorage.getItem(KEYS) || '{}'); } catch { return {}; }
  };
  const getKey = (slug) => keys()[slug] || '';
  const setKey = (slug, key) => {
    const k = keys();
    k[slug] = key;
    try { localStorage.setItem(KEYS, JSON.stringify(k)); } catch {}
  };

  // anonymous per-browser id, used so a viewer can only vote / enter once
  function voter() {
    try {
      let v = localStorage.getItem('streamnet.voter');
      if (!v) { v = Math.random().toString(36).slice(2, 12) + Date.now().toString(36); localStorage.setItem('streamnet.voter', v); }
      return v;
    } catch { return 'anon' + Math.random().toString(36).slice(2, 8); }
  }

  // ----- look: "modern" or "cable" -----
  const look = (() => {
    let def = 'modern';
    const listeners = [];
    const pref = () => { try { const v = localStorage.getItem(LOOK_KEY); return v === 'cable' || v === 'modern' ? v : null; } catch { return null; } };
    const effective = () => pref() || def;
    function apply() {
      const l = effective();
      document.documentElement.classList.toggle('cable', l === 'cable');
      const b = document.getElementById('lookToggle');
      if (b) {
        b.textContent = l === 'cable' ? '📺 Cable look: on' : '📺 Cable look: off';
        b.setAttribute('aria-pressed', String(l === 'cable'));
      }
      listeners.forEach((f) => f(l));
    }
    function toggle() {
      const next = effective() === 'cable' ? 'modern' : 'cable';
      try { localStorage.setItem(LOOK_KEY, next); } catch {}
      apply();
    }
    return {
      init(d) {
        if (d === 'cable' || d === 'modern') def = d;
        const b = document.getElementById('lookToggle');
        if (b && !b.dataset.bound) { b.dataset.bound = '1'; b.addEventListener('click', toggle); }
        apply();
      },
      setDefault(d) { if (d === 'cable' || d === 'modern') { def = d; apply(); } },
      effective,
      onChange(f) { listeners.push(f); },
    };
  })();

  function wsUrl() {
    return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws';
  }

  // WebSocket that reconnects with backoff. handlers: onopen(send), onmessage(msg)
  function socket(onOpen, onMessage, onStatus) {
    let ws, tries = 0, closed = false;
    const api = {
      send: (o) => ws && ws.readyState === 1 && ws.send(JSON.stringify(o)),
      close: () => { closed = true; try { ws.close(); } catch {} },
      // drop the connection but let it reconnect and re-register
      reset: () => { try { ws.close(); } catch {} },
    };
    function connect() {
      ws = new WebSocket(wsUrl());
      ws.onopen = () => { tries = 0; onStatus && onStatus(true); onOpen(api.send); };
      ws.onmessage = (e) => { try { onMessage(JSON.parse(e.data)); } catch (err) { console.error(err); } };
      ws.onclose = () => {
        onStatus && onStatus(false);
        if (closed) return;
        setTimeout(connect, Math.min(1000 * 2 ** tries++, 8000));
      };
    }
    connect();
    return api;
  }

  function addChat(log, m) {
    const row = document.createElement('div');
    const b = document.createElement('b');
    if (m.host) b.className = 'host';
    b.textContent = m.name + ': ';
    row.append(b, document.createTextNode(m.text));
    log.appendChild(row);
    while (log.children.length > 150) log.firstChild.remove();
    log.scrollTop = log.scrollHeight;
  }

  const chLabel = (n) => 'CH ' + String(n).padStart(2, '0');

  return { $, api, config, now, toast, getKey, setKey, keys, voter, look, socket, addChat, chLabel };
})();
