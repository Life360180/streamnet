'use strict';
// Runs in <head> before first paint so the chosen look doesn't flash.
try { if (localStorage.getItem('streamnet.look') === 'cable') document.documentElement.classList.add('cable'); } catch (e) {}
