'use strict';
// The channel guide list, used on /guide and as the in-player overlay (press G).
window.Guide = (() => {
  const h = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };
  const pad = (n) => String(n).padStart(2, '0');

  // list: networks from /api/networks.  opts: { current, onPick(network) }
  function render(container, list, opts = {}) {
    const sorted = [...list].sort((a, b) => a.channel - b.channel);
    container.textContent = '';
    const head = h('div', 'grow ghead');
    head.append(h('span', 'gch', 'CH'), h('span', 'gname', 'NETWORK'), h('span', 'gnow', 'ON NOW'), h('span', 'gnext', 'NEXT'));
    container.appendChild(head);
    if (!sorted.length) container.appendChild(h('div', 'empty', 'No channels yet.'));
    sorted.forEach((n) => {
      const a = h('a', 'grow' + (n.live ? ' live' : '') + (n.slug === opts.current ? ' current' : ''));
      a.href = '/n/' + encodeURIComponent(n.slug);
      if (opts.onPick) a.addEventListener('click', (e) => { e.preventDefault(); opts.onPick(n); });
      const ch = h('span', 'gch', pad(n.channel));
      const name = h('span', 'gname');
      const chip = h('i', 'chip');
      chip.style.background = n.color;
      name.append(chip, document.createTextNode(n.name));
      const now = h('span', 'gnow');
      if (n.live) { now.append(h('b', 'livepill', 'LIVE'), document.createTextNode(' ' + (n.title || n.name) + (n.viewers ? '  · ' + n.viewers + ' watching' : ''))); }
      else now.textContent = n.tagline || 'Off air';
      const first = n.lineup && n.lineup[0];
      const next = h('span', 'gnext', first ? (first.when ? first.when + '  ' : '') + first.title : '—');
      a.append(ch, name, now, next);
      container.appendChild(a);
    });
  }
  return { render };
})();
