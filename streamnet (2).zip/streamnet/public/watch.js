'use strict';
(() => {
  const { $, api, config, socket, addChat, toast, look, chLabel } = SN;
  const slug = location.pathname.split('/')[2];
  const video = $('#video');

  let net = null;
  let pc = null;
  let pendingIce = [];
  let iceServers = [{ urls: 'stun:stun.l.google.com:19302' }];
  let isLive = false;
  let liveTitle = '';
  let startedAt = 0;
  let viewers = 0;
  let disconnectTimer = null;
  let send = () => {};
  let osdShown = false;

  let chatName = (() => {
    let n = '';
    try { n = localStorage.getItem('streamnet.name') || ''; } catch {}
    return n || 'guest-' + Math.floor(100 + Math.random() * 900);
  })();

  // ---------- widgets ----------
  const host = Widgets.createHost({
    side: $('#sideW'),
    below: $('#belowW'),
    zones: { tl: $('#z-tl'), tc: $('#z-tc'), tr: $('#z-tr'), bl: $('#z-bl'), br: $('#z-br'), ticker: $('#z-ticker') },
    floaters: $('#floaters'),
    send: (m) => send(m),
    chatName: () => chatName,
  });
  const pushStats = () => host.setStats({ viewers, live: isLive, startedAt });

  function renderTitle() {
    $('#title').textContent = isLive && liveTitle ? liveTitle : net ? net.name : '…';
  }

  function applyNet(n) {
    net = n;
    look.setDefault(n.look);
    document.title = n.name + (isLive ? ' — live' : '');
    $('#tagline').textContent = n.tagline;
    $('#player').style.borderColor = n.color;
    $('#chNum').textContent = chLabel(n.channel);
    $('#chName').textContent = n.name;
    if (n.live && !liveTitle) { liveTitle = n.title; startedAt = n.startedAt; }
    renderTitle();
    host.setNet(n);
    host.setWidgets(n.widgets || []);
    host.setAllRuntime(n.runtime);
    if (!osdShown) { osdShown = true; showOsd(); }
  }

  async function loadNet() {
    try {
      applyNet(await api('/api/networks/' + encodeURIComponent(slug)));
    } catch (e) {
      showOff('Network not found', 'Check the link, or head back to browse networks.');
      $('#title').textContent = 'Not found';
      $('#chNum').textContent = 'CH --';
    }
  }

  // ---------- on-screen display + channel surfing ----------
  let osdTimer = null;
  function showOsd() {
    const o = $('#osd');
    o.textContent = '';
    const a = document.createElement('div'); a.className = 'osd-ch'; a.textContent = net ? chLabel(net.channel) : '';
    const b = document.createElement('div'); b.className = 'osd-name'; b.textContent = net ? net.name : '';
    o.append(a, b);
    o.classList.add('show');
    clearTimeout(osdTimer);
    osdTimer = setTimeout(() => o.classList.remove('show'), 3500);
  }

  let chans = [];
  async function loadChans() {
    try { chans = (await api('/api/networks')).sort((a, b) => a.channel - b.channel); } catch {}
    return chans;
  }
  function tune(n) {
    if (!n || n.slug === slug) { closeGuide(); return; }
    $('#static').classList.add('on');
    try { sessionStorage.setItem('streamnet.tune', '1'); } catch {}
    setTimeout(() => { location.href = '/n/' + encodeURIComponent(n.slug); }, 300);
  }
  async function step(dir) {
    if (!chans.length) await loadChans();
    if (chans.length < 2) { toast('No other channels yet'); return; }
    const i = chans.findIndex((c) => c.slug === slug);
    tune(chans[(i + dir + chans.length) % chans.length]);
  }
  $('#chUp').onclick = () => step(1);
  $('#chDown').onclick = () => step(-1);

  // arriving from a channel change: static clears
  try {
    if (sessionStorage.getItem('streamnet.tune')) {
      sessionStorage.removeItem('streamnet.tune');
      $('#static').classList.add('on');
      setTimeout(() => $('#static').classList.remove('on'), 350);
    }
  } catch {}

  // ---------- guide overlay ----------
  let guideTimer = null;
  async function refreshGuide() {
    try { Guide.render($('#guideBody'), await api('/api/networks'), { current: slug, onPick: tune }); } catch {}
  }
  function openGuide() {
    $('#guideOv').hidden = false;
    refreshGuide();
    clearInterval(guideTimer);
    guideTimer = setInterval(refreshGuide, 5000);
    const cur = $('#guideBody .current');
    if (cur) cur.focus();
  }
  function closeGuide() { $('#guideOv').hidden = true; clearInterval(guideTimer); }
  $('#guideBtn').onclick = () => (($('#guideOv').hidden) ? openGuide() : closeGuide());
  $('#guideClose').onclick = closeGuide;
  $('#guideOv').addEventListener('click', (e) => { if (e.target.id === 'guideOv') closeGuide(); });

  document.addEventListener('keydown', (e) => {
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.ctrlKey || e.metaKey || e.altKey) return;
    switch (e.key) {
      case 'ArrowUp': case 'PageUp': e.preventDefault(); step(1); break;
      case 'ArrowDown': case 'PageDown': e.preventDefault(); step(-1); break;
      case 'g': case 'G': $('#guideOv').hidden ? openGuide() : closeGuide(); break;
      case 'Escape': closeGuide(); break;
      case 'm': case 'M': video.muted = !video.muted; $('#unmute').hidden = !video.muted || !isLive; break;
      case 'f': case 'F': document.fullscreenElement ? document.exitFullscreen() : $('#player').requestFullscreen(); break;
    }
  });

  // ---------- player states ----------
  function showOff(title, sub) {
    $('#offAir').hidden = false;
    $('#offTitle').textContent = title;
    $('#offSub').textContent = sub;
    $('#badge').textContent = 'OFF AIR';
    $('#badge').className = 'badge off';
    $('#unmute').hidden = true;
  }
  function showLive() {
    $('#offAir').hidden = true;
    $('#badge').textContent = 'LIVE';
    $('#badge').className = 'badge';
    $('#unmute').hidden = !video.muted;
  }
  function closePc() {
    clearTimeout(disconnectTimer);
    if (pc) { pc.onicecandidate = pc.ontrack = pc.onconnectionstatechange = null; pc.close(); pc = null; }
    pendingIce = [];
    video.srcObject = null;
  }

  function newPc(snd) {
    pc = new RTCPeerConnection({ iceServers });
    pc.onicecandidate = (e) => e.candidate && snd({ type: 'signal', data: { candidate: e.candidate } });
    pc.ontrack = (e) => {
      if (video.srcObject !== e.streams[0]) video.srcObject = e.streams[0];
      video.play().catch(() => {});
      showLive();
    };
    pc.onconnectionstatechange = () => {
      const s = pc && pc.connectionState;
      clearTimeout(disconnectTimer);
      if (s === 'failed' || s === 'disconnected') {
        showOff('Reconnecting…', 'The connection dropped. Hang tight.');
        disconnectTimer = setTimeout(() => { closePc(); sock.reset(); }, s === 'failed' ? 500 : 5000);
      }
      if (s === 'connected') showLive();
    };
    return pc;
  }

  async function onSignal(data, snd) {
    if (data.sdp) {
      if (!pc) newPc(snd);
      await pc.setRemoteDescription(data.sdp);
      for (const c of pendingIce) { try { await pc.addIceCandidate(c); } catch {} }
      pendingIce = [];
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      snd({ type: 'signal', data: { sdp: pc.localDescription } });
    } else if (data.candidate) {
      if (pc && pc.remoteDescription) { try { await pc.addIceCandidate(data.candidate); } catch {} }
      else pendingIce.push(data.candidate);
    }
  }

  const sock = socket(
    (s) => { send = s; closePc(); s({ type: 'watch', slug }); },
    (m) => {
      switch (m.type) {
        case 'hello':
          isLive = m.live;
          liveTitle = m.title || '';
          startedAt = m.startedAt || 0;
          host.setAllRuntime(m.runtime);
          if (m.live) { $('#offTitle').textContent = 'Connecting…'; $('#offSub').textContent = 'Tuning in to the broadcast'; }
          else showOff('Off air', "This network isn't live right now. This page will start automatically when it is.");
          renderTitle(); pushStats();
          break;
        case 'live':
          isLive = true;
          liveTitle = m.title || '';
          startedAt = m.startedAt || Date.now();
          $('#offTitle').textContent = 'Connecting…';
          $('#offSub').textContent = 'Tuning in to the broadcast';
          renderTitle(); pushStats();
          break;
        case 'offline':
          isLive = false;
          liveTitle = '';
          closePc();
          showOff('Off air', 'The broadcast has ended. This page will start automatically when they return.');
          renderTitle(); pushStats();
          break;
        case 'signal': onSignal(m.data, send).catch(console.error); break;
        case 'count': {
          viewers = m.n;
          const c = $('#count');
          c.hidden = false;
          c.textContent = m.n + ' watching';
          pushStats();
          break;
        }
        case 'title': liveTitle = m.title; renderTitle(); break;
        case 'net': applyNet(m.net); break;
        case 'runtime': host.setRuntime(m.id, m.state); break;
        case 'reaction': host.react(m.emoji); break;
        case 'chat': addChat($('#log'), m); break;
        case 'full':
          showOff('Stream is full', 'This broadcast has reached its viewer limit (' + m.max + '). Try again in a bit.');
          sock.close();
          break;
        case 'error': showOff('Not found', m.error || 'Something went wrong.'); break;
      }
    }
  );

  // chat
  $('#chatForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const t = $('#chatText').value.trim();
    if (!t) return;
    if (t.startsWith('/nick ')) {
      chatName = t.slice(6).trim().slice(0, 20) || chatName;
      try { localStorage.setItem('streamnet.name', chatName); } catch {}
      toast('Chat name: ' + chatName);
    } else {
      send({ type: 'chat', name: chatName, text: t });
    }
    $('#chatText').value = '';
  });

  $('#unmute').onclick = () => { video.muted = false; video.play().catch(() => {}); $('#unmute').hidden = true; };
  video.addEventListener('playing', () => { $('#unmute').hidden = !video.muted; });
  video.addEventListener('dblclick', () => (document.fullscreenElement ? document.exitFullscreen() : $('#player').requestFullscreen()));

  // ---------- boot ----------
  config().then((c) => {
    iceServers = c.iceServers;
    $('#siteName').textContent = c.siteName;
    look.init(c.defaultLook);
    loadNet();
  });
  loadChans();
  setInterval(loadNet, 30000); // safety net in case a push is missed
})();
