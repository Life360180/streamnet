'use strict';
// Widget renderers, the live "host" that keeps them in sync, the studio editor form and live controls.
window.Widgets = (() => {
  const S = window.WidgetSchema;
  const h = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };
  const safeUrl = (u) => (/^https?:\/\/[^\s<>"'\\]{3,300}$/i.test(u || '') ? u : '');
  const pad = (n) => String(n).padStart(2, '0');
  const fmtMS = (s) => pad(Math.floor(s / 60)) + ':' + pad(s % 60);

  function shell(w, title) {
    const ov = w.place === 'overlay';
    const root = h('div', 'w w-' + w.type + (ov ? ' ov' : ' box'));
    if (title && !ov) root.appendChild(h('h4', null, title));
    return root;
  }
  function link(text, url, cls) {
    const a = h('a', cls, text);
    const u = safeUrl(url);
    if (u) { a.href = u; a.target = '_blank'; a.rel = 'noopener noreferrer nofollow'; }
    return a;
  }
  function every(api, fn, ms) {
    fn();
    const iv = setInterval(fn, ms);
    api.onDispose(() => clearInterval(iv));
  }

  // Why a widget is currently invisible to viewers ('' = it shows)
  function needs(w) {
    const c = w.cfg;
    switch (w.type) {
      case 'announcement': return c.active ? '' : 'Switched off';
      case 'links': return c.items.length ? '' : 'Add at least one link';
      case 'support': return safeUrl(c.url) ? '' : 'Add a link to show this';
      case 'countdown': return c.target ? '' : 'Pick a date & time';
      case 'nownext': return c.now || c.next ? '' : 'Fill in now / next';
      case 'poll': return c.options.length >= 2 ? '' : 'Needs 2+ options';
      case 'ticker': case 'rotator': return c.items.length ? '' : 'Add some messages';
      case 'lowerthird': return c.visible ? '' : 'Hidden until you show it (Live controls)';
      default: return '';
    }
  }

  // which on-video zone each overlay widget lives in
  const ZONE = {
    clock: () => 'tl', countdown: () => 'tl', timer: () => 'tl', nownext: () => 'bl', scoreboard: () => 'tc',
    rotator: () => 'bl', lowerthird: () => 'bl', ticker: () => 'ticker', bug: (c) => c.pos || 'tr',
  };

  // ---------------------------------------------------------------- renderers
  const R = {
    clock: { render(c, api, w) {
      const root = shell(w);
      const t = h('div', 'w-time');
      if (c.label) root.appendChild(h('div', 'w-label', c.label));
      root.appendChild(t);
      const o = { hour: '2-digit', minute: '2-digit', hour12: !c.h24 };
      if (c.secs) o.second = '2-digit';
      if (c.tz !== 'local') o.timeZone = c.tz;
      let f;
      try { f = new Intl.DateTimeFormat([], o); } catch { f = new Intl.DateTimeFormat([], { hour: '2-digit', minute: '2-digit' }); }
      every(api, () => { t.textContent = f.format(new Date(api.now())); }, c.secs ? 1000 : 5000);
      return root;
    } },

    countdown: { render(c, api, w) {
      const root = shell(w);
      const t = h('div', 'w-time');
      root.append(h('div', 'w-label', c.label), t);
      const target = Date.parse(c.target);
      every(api, () => {
        let s = Math.floor((target - api.now()) / 1000);
        t.classList.toggle('done', s <= 0);
        if (s <= 0) { t.textContent = c.done || 'Now!'; return; }
        const d = Math.floor(s / 86400); s %= 86400;
        const hh = Math.floor(s / 3600); s %= 3600;
        t.textContent = (d ? d + 'd ' : '') + pad(hh) + ':' + pad(Math.floor(s / 60)) + ':' + pad(s % 60);
      }, 1000);
      return root;
    } },

    timer: { render(c, api, w) {
      const root = shell(w);
      const t = h('div', 'w-time');
      root.append(h('div', 'w-label', c.label), t);
      const end = c.endAt ? Date.parse(c.endAt) : NaN;
      const running = !Number.isNaN(end);
      every(api, () => {
        let left;
        if (running) left = Math.max(0, Math.ceil((end - api.now()) / 1000));
        else if (c.pausedLeft >= 0) left = c.pausedLeft;
        else left = c.minutes * 60;
        t.textContent = fmtMS(left);
        t.classList.toggle('done', running && left === 0);
        root.classList.toggle('running', running && left > 0);
      }, running ? 500 : 60000);
      return root;
    } },

    nownext: { render(c, api, w) {
      const root = shell(w, 'Now & next');
      if (c.now) { const r = h('div', 'nn'); r.append(h('span', 'tagnow', 'NOW'), h('span', null, c.now)); root.appendChild(r); }
      if (c.next) { const r = h('div', 'nn'); r.append(h('span', 'tagnext', 'NEXT'), h('span', null, (c.nextTime ? c.nextTime + ' · ' : '') + c.next)); root.appendChild(r); }
      return root;
    } },

    announcement: { render(c, api, w) {
      const root = h('div', 'w w-announcement box ann-' + c.style);
      root.append(h('span', 'ann-icon', c.style === 'alert' ? '⚠️' : c.style === 'party' ? '🎉' : '📣'), h('div', 'ann-text', c.text));
      return root;
    } },

    links: { render(c, api, w) {
      const root = shell(w, c.title);
      const ul = h('div', 'linklist');
      c.items.forEach((i) => ul.appendChild(link(i.label, i.url, 'linkbtn')));
      root.appendChild(ul);
      return root;
    } },

    support: { render(c, api, w) {
      const root = shell(w);
      root.appendChild(link('💛 ' + c.label, c.url, 'btn primary wide'));
      if (c.note) root.appendChild(h('div', 'note', c.note));
      return root;
    } },

    sponsor: { render(c, api, w) {
      const root = shell(w);
      root.appendChild(h('div', 'spon-tag', 'SPONSOR'));
      root.appendChild(c.url ? link(c.name, c.url, 'spon-name') : h('div', 'spon-name', c.name));
      if (c.text) root.appendChild(h('div', 'note', c.text));
      return root;
    } },

    about: { render(c, api, w) {
      const root = shell(w, c.title);
      root.appendChild(h('div', 'about-text', c.text || 'Add a description in the studio.'));
      return root;
    } },

    schedule: { ctx: true, render(c, api, w) {
      const root = shell(w, c.title);
      const ul = h('ul', 'guide');
      const lineup = (api.net() && api.net().lineup) || [];
      if (!lineup.length) {
        const li = h('li', 'dim', 'No schedule posted yet.');
        li.style.display = 'block';
        ul.appendChild(li);
      }
      lineup.forEach((r) => { const li = h('li'); li.append(h('time', null, r.when || '—'), h('span', null, r.title)); ul.appendChild(li); });
      root.appendChild(ul);
      return root;
    } },

    stats: { stats: true, render(c, api, w) {
      const root = shell(w, c.title);
      const st = api.stats();
      const row = h('div', 'statrow');
      if (c.showViewers) { const d = h('div'); d.append(h('b', null, String(st.viewers || 0)), h('span', null, 'watching')); row.appendChild(d); }
      if (c.showUptime) {
        const d = h('div'); const b = h('b', null, st.live ? '0:00' : '—');
        d.append(b, h('span', null, st.live ? 'on air' : 'off air'));
        row.appendChild(d);
        if (st.live && st.startedAt) {
          every(api, () => {
            const s = Math.max(0, Math.floor((api.now() - st.startedAt) / 1000));
            b.textContent = s >= 3600 ? Math.floor(s / 3600) + ':' + pad(Math.floor(s / 60) % 60) + ':' + pad(s % 60) : Math.floor(s / 60) + ':' + pad(s % 60);
          }, 1000);
        }
      }
      root.appendChild(row);
      return root;
    } },

    poll: { runtime: true, render(c, api, w) {
      const root = shell(w, '🗳️ ' + c.question);
      const st = api.rt() || { counts: [], total: 0, rev: 0 };
      const key = 'streamnet.vote.' + w.id;
      let mine = null;
      try { const v = JSON.parse(localStorage.getItem(key) || 'null'); if (v && v.rev === st.rev) mine = v.idx; } catch {}
      const canVote = !api.studio && !c.closed && mine === null;
      c.options.forEach((o, i) => {
        if (canVote) {
          const b = h('button', 'opt', o);
          b.onclick = () => {
            api.send({ type: 'vote', id: w.id, idx: i, voter: api.voter });
            try { localStorage.setItem(key, JSON.stringify({ idx: i, rev: st.rev })); } catch {}
            st.counts[i] = (st.counts[i] || 0) + 1;
            st.total = (st.total || 0) + 1;
            api.rerender();
          };
          root.appendChild(b);
        } else {
          const n = st.counts[i] || 0;
          const pct = st.total ? Math.round((n * 100) / st.total) : 0;
          const row = h('div', 'res' + (mine === i ? ' mine' : ''));
          const bar = h('div', 'fill');
          bar.style.width = pct + '%';
          const lab = h('div', 'lab');
          lab.append(h('span', null, o), h('b', null, pct + '%'));
          row.append(bar, lab);
          root.appendChild(row);
        }
      });
      root.appendChild(h('div', 'note', (st.total || 0) + (st.total === 1 ? ' vote' : ' votes') + (c.closed ? ' · voting closed' : '')));
      return root;
    } },

    scoreboard: { render(c, api, w) {
      const root = shell(w, c.title && w.place !== 'overlay' ? c.title : null);
      if (w.place === 'overlay') root.appendChild(h('div', 'sb-title', [c.title, c.period].filter(Boolean).join(' · ')));
      else if (c.period) root.appendChild(h('div', 'note', c.period));
      const row = h('div', 'sb-row');
      row.append(h('span', 'tm', c.teamA), h('b', null, String(c.scoreA)), h('i', null, '–'), h('b', null, String(c.scoreB)), h('span', 'tm', c.teamB));
      root.appendChild(row);
      return root;
    } },

    rotator: { render(c, api, w) {
      const root = shell(w, c.title);
      const line = h('div', 'rot-line');
      root.appendChild(line);
      let i = 0;
      const show = () => {
        line.classList.remove('in'); void line.offsetWidth;
        line.textContent = c.items[i % c.items.length];
        line.classList.add('in');
        i++;
      };
      every(api, show, c.seconds * 1000);
      return root;
    } },

    giveaway: { runtime: true, render(c, api, w) {
      const root = shell(w, '🎁 Giveaway');
      const st = api.rt() || { count: 0, winner: '', rev: 0 };
      const key = 'streamnet.enter.' + w.id;
      let entered = false;
      try { const v = JSON.parse(localStorage.getItem(key) || 'null'); entered = !!(v && v.rev === st.rev); } catch {}
      root.appendChild(h('div', 'prize', c.prize));
      if (st.winner) root.appendChild(h('div', 'winner', '🎉 Winner: ' + st.winner));
      else if (!c.open) root.appendChild(h('div', 'note', 'Entries are closed.'));
      else if (api.studio) root.appendChild(h('div', 'note', 'Viewers see an Enter button here.'));
      else if (entered) root.appendChild(h('div', 'note', "✅ You're in! Good luck."));
      else {
        const b = h('button', 'btn primary wide', 'Enter giveaway');
        b.onclick = () => {
          api.send({ type: 'enter', id: w.id, voter: api.voter, name: api.chatName() });
          try { localStorage.setItem(key, JSON.stringify({ rev: st.rev })); } catch {}
          st.count = (st.count || 0) + 1;
          api.rerender();
        };
        root.appendChild(b);
      }
      root.appendChild(h('div', 'note', (st.count || 0) + (st.count === 1 ? ' entry' : ' entries')));
      return root;
    } },

    reactions: { render(c, api, w) {
      const root = shell(w, c.title);
      const row = h('div', 'reactrow');
      S.REACTIONS.forEach((e) => {
        const b = h('button', 'react', e);
        b.setAttribute('aria-label', 'React ' + e);
        if (api.studio) b.disabled = true;
        else b.onclick = () => api.send({ type: 'react', emoji: e });
        row.appendChild(b);
      });
      root.appendChild(row);
      return root;
    } },

    ticker: { render(c, api, w) {
      const root = h('div', 'w w-ticker ticker ' + (w.place === 'overlay' ? 'ov-ticker' : 'box-ticker'));
      if (c.label) root.appendChild(h('div', 'tag', c.label));
      const view = h('div', 'view');
      const track = h('div', 'track');
      const text = c.items.join('   ★   ') + '   ★   ';
      track.append(h('span', null, text), h('span', null, text));
      view.appendChild(track);
      root.appendChild(view);
      const cps = { slow: 14, normal: 24, fast: 38 }[c.speed] || 24;
      track.style.animationDuration = Math.max(10, text.length / cps) + 's';
      return root;
    } },

    lowerthird: { render(c, api, w) {
      const root = h('div', 'w w-lowerthird ov');
      root.append(h('div', 'l1', c.line1), h('div', 'l2', c.line2));
      return root;
    } },

    bug: { render(c, api, w) {
      const root = h('div', 'w w-bug ov');
      const n = api.net() || {};
      root.appendChild(h('span', 'bugname', c.text || n.name || ''));
      if (c.showChannel && n.channel) root.appendChild(h('span', 'bugch', 'CH ' + pad(n.channel)));
      return root;
    } },
  };
  R.bug.ctx = true;

  const sigOf = (w) => JSON.stringify([w.type, w.place, w.cfg]);

  // ---------------------------------------------------------------- the host
  // o: { side, below, zones:{tl,tr,tc,bl,br,ticker}, floaters, studio, send(msg), chatName() }
  function createHost(o) {
    const SN = window.SN;
    const items = new Map();
    let order = [];
    let net = null;
    let stats = { viewers: 0, live: false, startedAt: 0 };
    const rt = {};
    let needLayout = false;

    function mkapi(it) {
      const disposers = [];
      return {
        disposers,
        studio: !!o.studio,
        voter: SN.voter(),
        now: SN.now,
        send: (m) => o.send && o.send(m),
        chatName: o.chatName || (() => 'guest'),
        net: () => net,
        stats: () => stats,
        rt: () => rt[it.w.id],
        onDispose: (f) => disposers.push(f),
        rerender: () => { refill(it); flush(); },
      };
    }
    function fill(it) {
      it.api = mkapi(it);
      it.el = null;
      if (needs(it.w)) return;
      try { it.el = R[it.w.type].render(it.w.cfg, it.api, it.w); } catch (e) { console.error('widget failed', it.w.type, e); }
    }
    function teardown(it) { it.api.disposers.splice(0).forEach((f) => { try { f(); } catch {} }); }
    function refill(it) {
      const prev = it.el;
      teardown(it);
      fill(it);
      if (prev && prev.parentNode) { if (it.el) prev.replaceWith(it.el); else prev.remove(); }
      else if (it.el) needLayout = true;
    }
    function containerFor(it) {
      const w = it.w;
      if (w.place === 'overlay') return (o.zones || {})[(ZONE[w.type] || (() => 'tl'))(w.cfg)] || null;
      return w.place === 'below' ? o.below : o.side;
    }
    function layout() {
      [o.side, o.below, ...Object.values(o.zones || {})].filter(Boolean).forEach((c) => c.replaceChildren());
      for (const it of order) {
        if (!it.el) continue;
        const c = containerFor(it);
        if (c) c.appendChild(it.el);
      }
    }
    function flush() { if (needLayout) { needLayout = false; layout(); } }

    function setWidgets(list) {
      const seen = new Set();
      const next = [];
      let relayout = false;
      for (const w of list) {
        seen.add(w.id);
        let it = items.get(w.id);
        const sig = sigOf(w);
        if (!it) {
          it = { w, sig };
          fill(it);
          items.set(w.id, it);
          relayout = true;
        } else if (it.sig !== sig) {
          const moved = it.w.place !== w.place;
          it.w = w; it.sig = sig;
          if (moved) { teardown(it); fill(it); relayout = true; } else refill(it);
        } else it.w = w;
        next.push(it);
      }
      for (const [id, it] of items) {
        if (!seen.has(id)) { teardown(it); if (it.el) it.el.remove(); items.delete(id); }
      }
      if (next.map((i) => i.w.id).join() !== order.map((i) => i.w.id).join()) relayout = true;
      order = next;
      if (relayout || needLayout) { needLayout = false; layout(); }
    }
    function refillWhere(pred) { order.forEach((it) => { if (pred(it.def || R[it.w.type])) refill(it); }); flush(); }
    return {
      setWidgets,
      setNet(n) { net = n; refillWhere((d) => d.ctx); },
      setStats(s) { stats = s; refillWhere((d) => d.stats); },
      setRuntime(id, state) {
        rt[id] = state;
        const it = items.get(id);
        if (it && R[it.w.type].runtime) { refill(it); flush(); }
      },
      setAllRuntime(map) { Object.entries(map || {}).forEach(([id, s]) => { rt[id] = s; }); refillWhere((d) => d.runtime); },
      react(emoji) {
        if (!o.floaters) return;
        const s = h('span', null, emoji);
        s.style.left = 4 + Math.random() * 88 + '%';
        s.style.animationDuration = 2 + Math.random() * 1.4 + 's';
        o.floaters.appendChild(s);
        while (o.floaters.children.length > 40) o.floaters.firstChild.remove();
        setTimeout(() => s.remove(), 3600);
      },
      hasType: (t) => order.some((it) => it.w.type === t),
    };
  }

  // ---------------------------------------------------------------- editor form (studio)
  const pad2 = (n) => String(n).padStart(2, '0');
  function isoToLocal(iso) {
    const d = new Date(iso);
    if (!iso || Number.isNaN(d.getTime())) return '';
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + 'T' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }
  const localToIso = (s) => { const d = new Date(s); return s && !Number.isNaN(d.getTime()) ? d.toISOString() : ''; };

  function field(f, val, set) {
    const wrap = h('div', 'fld');
    if (f.t === 'bool') {
      const lab = h('label', 'chk');
      const i = h('input'); i.type = 'checkbox'; i.checked = !!val;
      i.onchange = () => set(i.checked);
      lab.append(i, document.createTextNode(' ' + f.label));
      wrap.appendChild(lab);
      return wrap;
    }
    if (f.t === 'list') return listField(f, val, set);
    wrap.appendChild(h('label', null, f.label || f.k));
    let input;
    if (f.t === 'textarea') {
      input = h('textarea'); input.rows = 3; input.maxLength = f.max || 500; input.value = val || '';
      input.oninput = () => set(input.value);
    } else if (f.t === 'select') {
      input = h('select');
      f.opts.forEach(([v, l]) => { const op = h('option', null, l); op.value = v; input.appendChild(op); });
      input.value = val;
      input.onchange = () => set(input.value);
    } else if (f.t === 'number') {
      input = h('input'); input.type = 'number';
      if (f.min != null) input.min = f.min;
      if (f.maxv != null) input.max = f.maxv;
      input.value = val;
      input.oninput = () => set(input.value === '' ? f.def : Number(input.value));
    } else if (f.t === 'datetime') {
      input = h('input'); input.type = 'datetime-local'; input.value = isoToLocal(val);
      input.onchange = () => set(localToIso(input.value));
    } else if (f.t === 'color') {
      input = h('input'); input.type = 'color'; input.value = val || '#e5484d';
      input.oninput = () => set(input.value);
    } else {
      input = h('input'); input.type = 'text'; input.maxLength = f.max || 300;
      input.placeholder = f.ph || (f.t === 'url' ? 'https://…' : '');
      input.value = val || '';
      input.oninput = () => set(input.value);
    }
    wrap.appendChild(input);
    return wrap;
  }

  function listField(f, val, set) {
    const arr = S.clone(val) || [];
    const wrap = h('div', 'fld');
    wrap.appendChild(h('label', null, f.label || f.k));
    const rows = h('div', 'listrows');
    wrap.appendChild(rows);
    const add = h('button', 'btn small', '+ Add');
    add.type = 'button';
    const max = f.maxItems || 10;
    function draw() {
      rows.textContent = '';
      arr.forEach((item, idx) => {
        const row = h('div', 'listrow');
        if (f.of) {
          const i = h('input'); i.type = 'text'; i.maxLength = f.of.max || 100; i.value = item;
          i.oninput = () => { arr[idx] = i.value; set(arr.slice()); };
          row.appendChild(i);
        } else {
          f.fields.forEach((sf) => {
            const i = h('input'); i.type = 'text'; i.maxLength = sf.max || 300;
            i.placeholder = sf.label || sf.k; i.value = (item && item[sf.k]) || '';
            i.oninput = () => { arr[idx] = { ...(arr[idx] || {}), [sf.k]: i.value }; set(arr.slice()); };
            row.appendChild(i);
          });
        }
        const x = h('button', 'btn small', '✕'); x.type = 'button'; x.setAttribute('aria-label', 'Remove');
        x.onclick = () => { arr.splice(idx, 1); set(arr.slice()); draw(); };
        row.appendChild(x);
        rows.appendChild(row);
      });
      add.disabled = arr.length >= max;
    }
    add.onclick = () => {
      arr.push(f.of ? '' : Object.fromEntries(f.fields.map((sf) => [sf.k, ''])));
      draw();
      const last = rows.lastChild && rows.lastChild.querySelector('input');
      if (last) last.focus();
    };
    draw();
    wrap.appendChild(add);
    return wrap;
  }

  // onChange(newCfg) after every edit. Hidden fields are carried through untouched.
  function form(type, cfg, onChange) {
    const root = h('div', 'wform');
    const cur = S.clone(cfg);
    S.types[type].fields.filter((f) => !f.hidden).forEach((f) => {
      root.appendChild(field(f, cur[f.k], (v) => { cur[f.k] = v; onChange(S.clone(cur)); }));
    });
    return root;
  }

  // ---------------------------------------------------------------- live controls (studio)
  // ctl: { cfg(id), patch(id, patch), action(id, action), rt(id), now() }
  function controls(w, ctl) {
    const id = w.id;
    const c = w.cfg;
    const box = h('div', 'ctl');
    box.dataset.wid = id;
    const head = h('div', 'ctl-head');
    head.append(h('span', null, S.types[w.type].icon + ' ' + S.types[w.type].label));
    box.appendChild(head);
    const row = (...els) => { const r = h('div', 'ctl-row'); r.append(...els); box.appendChild(r); return r; };
    const btn = (label, fn, cls) => { const b = h('button', 'btn small ' + (cls || ''), label); b.type = 'button'; b.onclick = fn; return b; };
    const input = (val, ph, max) => { const i = h('input'); i.type = 'text'; i.value = val || ''; i.placeholder = ph || ''; i.maxLength = max || 100; return i; };
    const cur = () => ctl.cfg(id);

    switch (w.type) {
      case 'announcement': {
        row(btn(c.active ? 'Hide announcement' : 'Show announcement', () => ctl.patch(id, { active: !cur().active }), c.active ? '' : 'primary'));
        break;
      }
      case 'lowerthird': {
        const a = input(c.line1, 'Main line', 50), b = input(c.line2, 'Second line', 70);
        row(a); row(b);
        row(
          btn(c.visible ? '↻ Update on screen' : '▶ Show', async () => {
            await ctl.patch(id, { line1: a.value, line2: b.value, visible: true });
            const secs = cur().autohide;
            if (secs > 0) setTimeout(() => ctl.patch(id, { visible: false }), secs * 1000);
          }, 'primary'),
          btn('Hide', () => ctl.patch(id, { visible: false }))
        );
        break;
      }
      case 'scoreboard': {
        const team = (nameKey, scoreKey) => {
          const r = h('div', 'ctl-score');
          r.append(
            h('span', 'nm', cur()[nameKey]),
            btn('−', () => ctl.patch(id, { [scoreKey]: Math.max(0, cur()[scoreKey] - 1) })),
            h('b', null, String(cur()[scoreKey])),
            btn('+', () => ctl.patch(id, { [scoreKey]: cur()[scoreKey] + 1 }), 'primary')
          );
          return r;
        };
        row(team('teamA', 'scoreA')); row(team('teamB', 'scoreB'));
        const p = input(c.period, 'Period (e.g. 2nd half)', 16);
        row(p, btn('Set', () => ctl.patch(id, { period: p.value })), btn('Reset scores', () => ctl.patch(id, { scoreA: 0, scoreB: 0 })));
        break;
      }
      case 'poll': {
        const st = ctl.rt(id) || { counts: [], total: 0 };
        c.options.forEach((o, i) => {
          const n = st.counts[i] || 0;
          row(h('span', null, o + ' — ' + n + (st.total ? ' (' + Math.round((n * 100) / st.total) + '%)' : '')));
        });
        row(
          btn(c.closed ? 'Reopen voting' : 'Close voting', () => ctl.patch(id, { closed: !cur().closed })),
          btn('Reset votes', () => ctl.action(id, 'reset'))
        );
        break;
      }
      case 'giveaway': {
        const st = ctl.rt(id) || { count: 0, winner: '' };
        row(h('span', null, st.count + (st.count === 1 ? ' entry' : ' entries') + (st.winner ? ' · 🎉 ' + st.winner : '')));
        row(
          btn(c.open ? 'Close entries' : 'Open entries', () => ctl.patch(id, { open: !cur().open })),
          btn('🎲 Draw winner', () => ctl.action(id, 'draw'), 'primary'),
          btn('Reset', () => ctl.action(id, 'reset'))
        );
        break;
      }
      case 'timer': {
        const running = c.endAt && Date.parse(c.endAt) > ctl.now();
        row(
          btn(running ? '⏸ Pause' : '▶ Start', () => {
            const k = cur();
            if (k.endAt && Date.parse(k.endAt) > ctl.now()) {
              ctl.patch(id, { pausedLeft: Math.max(0, Math.ceil((Date.parse(k.endAt) - ctl.now()) / 1000)), endAt: '' });
            } else {
              const secs = k.pausedLeft >= 0 ? k.pausedLeft : k.minutes * 60;
              ctl.patch(id, { endAt: new Date(ctl.now() + secs * 1000).toISOString(), pausedLeft: -1 });
            }
          }, 'primary'),
          btn('Reset', () => ctl.patch(id, { endAt: '', pausedLeft: -1 }))
        );
        break;
      }
      case 'nownext': {
        const n = input(c.now, 'Now playing', 70), nx = input(c.next, 'Up next', 70), t = input(c.nextTime, 'Next starts (9:00 PM)', 20);
        row(n); row(nx); row(t, btn('Update', () => ctl.patch(id, { now: n.value, next: nx.value, nextTime: t.value }), 'primary'));
        break;
      }
      case 'ticker': {
        const i = input('', 'Add a headline…', 160);
        const add = () => { if (!i.value.trim()) return; ctl.patch(id, { items: [i.value.trim(), ...cur().items].slice(0, 15) }); i.value = ''; };
        i.addEventListener('keydown', (e) => e.key === 'Enter' && (e.preventDefault(), add()));
        row(i, btn('Add', add, 'primary'));
        break;
      }
      default: return null;
    }
    return box;
  }
  const hasControls = (type) => ['announcement', 'lowerthird', 'scoreboard', 'poll', 'giveaway', 'timer', 'nownext', 'ticker'].includes(type);

  return { createHost, form, controls, hasControls, needs, ZONE };
})();
