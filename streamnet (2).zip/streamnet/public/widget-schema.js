'use strict';
// Shared by the server (validation) and the browser (editor + templates).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.WidgetSchema = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const TZ = [
    ['local', "Viewer's local time"], ['UTC', 'UTC'], ['America/New_York', 'New York'], ['America/Chicago', 'Chicago'],
    ['America/Denver', 'Denver'], ['America/Los_Angeles', 'Los Angeles'], ['Europe/London', 'London'],
    ['Europe/Paris', 'Paris'], ['Europe/Berlin', 'Berlin'], ['Asia/Dubai', 'Dubai'], ['Asia/Kolkata', 'India'],
    ['Asia/Tokyo', 'Tokyo'], ['Australia/Sydney', 'Sydney'],
  ];
  const REACTIONS = ['👍', '❤️', '😂', '😮', '👏', '🔥'];
  const PLACES = { side: 'Sidebar', below: 'Under the video', overlay: 'On the video' };
  const LOOKS = { modern: 'Modern', cable: 'Cable TV' };

  // Field kinds: text textarea number select bool color datetime url list.  hidden:true = not shown in the editor.
  const types = {
    clock: {
      label: 'Clock', icon: '🕒', places: ['side', 'overlay'], desc: 'Show the time in any time zone.',
      fields: [
        { k: 'label', t: 'text', label: 'Label', max: 24, def: '' },
        { k: 'tz', t: 'select', label: 'Time zone', opts: TZ, def: 'local' },
        { k: 'h24', t: 'bool', label: '24-hour clock', def: false },
        { k: 'secs', t: 'bool', label: 'Show seconds', def: false },
      ],
    },
    countdown: {
      label: 'Countdown', icon: '⏳', places: ['side', 'overlay'], desc: 'Count down to a premiere, show or event.',
      fields: [
        { k: 'label', t: 'text', label: 'Label', max: 40, def: 'Next show in' },
        { k: 'target', t: 'datetime', label: 'Date & time', def: '' },
        { k: 'done', t: 'text', label: 'When it reaches zero', max: 40, def: "We're live!" },
      ],
    },
    timer: {
      label: 'Segment timer', icon: '⏱', places: ['side', 'overlay'], desc: 'A timer you start, pause and reset live from the studio.',
      fields: [
        { k: 'label', t: 'text', label: 'Label', max: 30, def: 'Segment ends in' },
        { k: 'minutes', t: 'number', label: 'Length (minutes)', min: 1, maxv: 600, int: true, def: 5 },
        { k: 'endAt', t: 'datetime', hidden: true, def: '' },
        { k: 'pausedLeft', t: 'number', hidden: true, min: -1, maxv: 36000, int: true, def: -1 },
      ],
    },
    nownext: {
      label: 'Now & Next', icon: '▶️', places: ['side', 'overlay'], desc: 'Tell viewers what is on now and what comes next.',
      fields: [
        { k: 'now', t: 'text', label: 'Now playing', max: 70, def: '' },
        { k: 'next', t: 'text', label: 'Up next', max: 70, def: '' },
        { k: 'nextTime', t: 'text', label: 'Next starts', max: 20, def: '', ph: '9:00 PM' },
      ],
    },
    announcement: {
      label: 'Announcement', icon: '📣', places: ['side', 'below'], desc: 'A highlighted message you can switch on and off.',
      fields: [
        { k: 'text', t: 'textarea', label: 'Message', max: 240, def: 'Welcome to the channel!' },
        { k: 'style', t: 'select', label: 'Style', opts: [['info', 'Info'], ['alert', 'Alert'], ['party', 'Celebration']], def: 'info' },
        { k: 'active', t: 'bool', label: 'Showing', def: true },
      ],
    },
    links: {
      label: 'Links', icon: '🔗', places: ['side', 'below'], desc: 'Social links and other places to find you.',
      fields: [
        { k: 'title', t: 'text', label: 'Title', max: 30, def: 'Follow us' },
        { k: 'items', t: 'list', label: 'Links', maxItems: 8, fields: [
          { k: 'label', t: 'text', label: 'Label', max: 30, def: '' },
          { k: 'url', t: 'url', label: 'https://…', def: '' },
        ], def: [] },
      ],
    },
    support: {
      label: 'Support button', icon: '💛', places: ['side', 'below'], desc: 'A tip, donate or merch button.',
      fields: [
        { k: 'label', t: 'text', label: 'Button text', max: 40, def: 'Support the channel' },
        { k: 'note', t: 'text', label: 'Note', max: 100, def: '' },
        { k: 'url', t: 'url', label: 'Link', def: '' },
      ],
    },
    sponsor: {
      label: 'Sponsor', icon: '🏷️', places: ['side', 'below'], desc: 'Show a sponsor or advertiser.',
      fields: [
        { k: 'name', t: 'text', label: 'Sponsor', max: 40, def: 'Your sponsor here' },
        { k: 'text', t: 'text', label: 'Message', max: 140, def: '' },
        { k: 'url', t: 'url', label: 'Link', def: '' },
      ],
    },
    about: {
      label: 'About', icon: 'ℹ️', places: ['side', 'below'], desc: 'A short blurb about your network or show.',
      fields: [
        { k: 'title', t: 'text', label: 'Title', max: 40, def: 'About' },
        { k: 'text', t: 'textarea', label: 'Text', max: 600, def: '' },
      ],
    },
    schedule: {
      label: 'Program guide', icon: '🗓️', places: ['side', 'below'], desc: 'Your schedule (edit it on the Schedule tab).',
      fields: [{ k: 'title', t: 'text', label: 'Title', max: 30, def: 'Program guide' }],
    },
    stats: {
      label: 'On-air stats', icon: '📊', places: ['side', 'below'], desc: 'Live viewer count and time on air.',
      fields: [
        { k: 'title', t: 'text', label: 'Title', max: 30, def: 'On air' },
        { k: 'showViewers', t: 'bool', label: 'Show viewers', def: true },
        { k: 'showUptime', t: 'bool', label: 'Show time on air', def: true },
      ],
    },
    poll: {
      label: 'Live poll', icon: '🗳️', places: ['side', 'below'], desc: 'Let viewers vote and watch results move live.',
      fields: [
        { k: 'question', t: 'text', label: 'Question', max: 100, def: 'What should we do next?' },
        { k: 'options', t: 'list', of: { t: 'text', max: 40 }, label: 'Options', maxItems: 5, def: ['Option A', 'Option B'] },
        { k: 'closed', t: 'bool', label: 'Voting closed', def: false },
      ],
    },
    scoreboard: {
      label: 'Scoreboard', icon: '🏆', places: ['side', 'below', 'overlay'], desc: 'Two teams, live scores you update with +/- buttons.',
      fields: [
        { k: 'title', t: 'text', label: 'Title', max: 24, def: 'LIVE' },
        { k: 'teamA', t: 'text', label: 'Team A', max: 16, def: 'HOME' },
        { k: 'teamB', t: 'text', label: 'Team B', max: 16, def: 'AWAY' },
        { k: 'scoreA', t: 'number', label: 'Score A', min: 0, maxv: 999, int: true, def: 0 },
        { k: 'scoreB', t: 'number', label: 'Score B', min: 0, maxv: 999, int: true, def: 0 },
        { k: 'period', t: 'text', label: 'Period / status', max: 16, def: '' },
      ],
    },
    rotator: {
      label: 'Rotating messages', icon: '🔄', places: ['side', 'below', 'overlay'], desc: 'Cycle through tips, headlines or shout-outs.',
      fields: [
        { k: 'title', t: 'text', label: 'Title', max: 30, def: 'Did you know?' },
        { k: 'items', t: 'list', of: { t: 'text', max: 140 }, label: 'Messages', maxItems: 12, def: ['Chat is open — say hi!', 'Share this channel with a friend.'] },
        { k: 'seconds', t: 'number', label: 'Seconds each', min: 3, maxv: 60, int: true, def: 6 },
      ],
    },
    giveaway: {
      label: 'Giveaway', icon: '🎁', places: ['side', 'below'], desc: 'Viewers enter; you draw a winner live.',
      fields: [
        { k: 'prize', t: 'text', label: 'Prize', max: 80, def: 'A shout-out on air!' },
        { k: 'open', t: 'bool', label: 'Entries open', def: true },
      ],
    },
    reactions: {
      label: 'Reactions', icon: '🎉', places: ['side', 'below'], desc: 'Emoji buttons that float up over the video.',
      fields: [{ k: 'title', t: 'text', label: 'Title', max: 24, def: 'React' }],
    },
    ticker: {
      label: 'News ticker', icon: '📰', places: ['overlay', 'below'], desc: 'A scrolling crawl across the bottom of the picture.',
      fields: [
        { k: 'label', t: 'text', label: 'Tag', max: 16, def: 'NEWS' },
        { k: 'items', t: 'list', of: { t: 'text', max: 160 }, label: 'Headlines', maxItems: 15, def: ['Welcome to the channel', 'Chat is open — say hi!'] },
        { k: 'speed', t: 'select', label: 'Speed', opts: [['slow', 'Slow'], ['normal', 'Normal'], ['fast', 'Fast']], def: 'normal' },
      ],
    },
    lowerthird: {
      label: 'Lower third', icon: '🪧', places: ['overlay'], desc: 'A name or caption bar you show and hide live.',
      fields: [
        { k: 'line1', t: 'text', label: 'Main line', max: 50, def: 'Name goes here' },
        { k: 'line2', t: 'text', label: 'Second line', max: 70, def: 'Title or caption' },
        { k: 'visible', t: 'bool', label: 'Visible', def: false },
        { k: 'autohide', t: 'number', label: 'Auto-hide after (seconds, 0 = stay)', min: 0, maxv: 120, int: true, def: 0 },
      ],
    },
    bug: {
      label: 'Channel bug', icon: '🅲', places: ['overlay'], desc: 'Your network name and channel number in a corner.',
      fields: [
        { k: 'text', t: 'text', label: 'Text (blank = network name)', max: 24, def: '' },
        { k: 'showChannel', t: 'bool', label: 'Show channel number', def: true },
        { k: 'pos', t: 'select', label: 'Corner', opts: [['tr', 'Top right'], ['tl', 'Top left'], ['br', 'Bottom right'], ['bl', 'Bottom left']], def: 'tr' },
      ],
    },
  };

  function clone(v) { return v === undefined ? v : JSON.parse(JSON.stringify(v)); }
  function defaults(type) {
    const out = {};
    for (const f of types[type].fields) out[f.k] = clone(f.def);
    return out;
  }

  // ---------- templates ----------
  const W = (type, place, cfg) => ({ type, place, cfg: cfg || {} });
  const templates = {
    classic: {
      name: 'Classic', icon: '📺', look: 'modern', desc: 'Clean and simple: program guide, on-air stats and room for your links.',
      widgets: [W('schedule', 'side'), W('stats', 'side'), W('links', 'side', { title: 'Find us elsewhere' })],
    },
    cable247: {
      name: '24/7 Cable Channel', icon: '📡', look: 'cable', desc: 'Looks like a real cable channel: channel bug, clock, now & next and an info crawl.',
      widgets: [
        W('bug', 'overlay', { pos: 'tr' }),
        W('clock', 'overlay', { label: '' }),
        W('nownext', 'overlay', { now: '{name} — on the air', next: 'More programming soon', nextTime: '' }),
        W('ticker', 'overlay', { label: 'INFO', items: ['Welcome to {name}', 'Share this channel with a friend', 'Chat is open — say hello!'] }),
        W('schedule', 'side'), W('stats', 'side'), W('reactions', 'side'),
        W('sponsor', 'side', { name: 'Your ad here', text: 'Sponsor this channel' }),
      ],
    },
    news: {
      name: 'News Network', icon: '🗞️', look: 'cable', desc: 'Breaking-news crawl, lower thirds, a headline rotator, poll and next-bulletin countdown.',
      widgets: [
        W('bug', 'overlay', { pos: 'tr' }),
        W('clock', 'overlay', { label: '' }),
        W('lowerthird', 'overlay', { line1: 'Reporter Name', line2: 'Reporting live from the studio', visible: true }),
        W('ticker', 'overlay', { label: 'BREAKING', items: ['Top story goes here', 'Second headline goes here', 'Weather, sports and more at the top of the hour'], speed: 'normal' }),
        W('countdown', 'side', { label: 'Next bulletin in', target: '+60m', done: 'On the air now' }),
        W('rotator', 'side', { title: 'Top stories', items: ['Story one — edit me in the studio', 'Story two — edit me in the studio', 'Story three — edit me in the studio'], seconds: 7 }),
        W('poll', 'side', { question: 'What should we cover next?', options: ['Local news', 'Sports', 'Entertainment'] }),
        W('schedule', 'side'), W('stats', 'side'),
      ],
    },
    sports: {
      name: 'Sports Network', icon: '🏟️', look: 'cable', desc: 'Live scoreboard on the picture, scores crawl, kickoff countdown, prediction poll and reactions.',
      widgets: [
        W('scoreboard', 'overlay', { title: 'LIVE', teamA: 'HOME', teamB: 'AWAY', period: '1st' }),
        W('bug', 'overlay', { pos: 'tr' }),
        W('countdown', 'overlay', { label: 'Kickoff in', target: '+45m', done: 'Underway!' }),
        W('ticker', 'overlay', { label: 'SCORES', items: ['Add your scores here', 'Update them any time from the studio'] }),
        W('poll', 'side', { question: 'Who wins tonight?', options: ['Home', 'Away', 'Draw'] }),
        W('reactions', 'side', { title: 'Cheer' }),
        W('schedule', 'side'), W('stats', 'side'), W('support', 'side', { label: 'Support the team', note: '' }),
      ],
    },
    gaming: {
      name: 'Gaming & Esports', icon: '🎮', look: 'modern', desc: 'Reactions, a vote for the next game, giveaways, a BRB timer and support links.',
      widgets: [
        W('bug', 'overlay', { pos: 'tr' }),
        W('timer', 'overlay', { label: 'Back in', minutes: 5 }),
        W('poll', 'side', { question: 'What should I play next?', options: ['Game A', 'Game B', 'Game C'] }),
        W('giveaway', 'side', { prize: 'A shout-out on stream!' }),
        W('reactions', 'side', { title: 'GG' }),
        W('links', 'side', { title: 'Socials' }), W('support', 'side'), W('stats', 'side'),
      ],
    },
    music: {
      name: 'Music & Radio TV', icon: '🎵', look: 'modern', desc: 'Now playing, a request line, reactions and a tip jar.',
      widgets: [
        W('bug', 'overlay', { pos: 'tl' }),
        W('nownext', 'overlay', { now: 'Now playing: —', next: 'Up next: —', nextTime: '' }),
        W('rotator', 'side', { title: 'Request line', items: ['Type your requests in the chat!', 'Shout-outs read on air', 'Tell us what you want to hear'], seconds: 6 }),
        W('reactions', 'side'), W('links', 'side', { title: 'Listen elsewhere' }), W('support', 'side', { label: 'Tip the DJ' }), W('stats', 'side'),
      ],
    },
    community: {
      name: 'Community & Events', icon: '⛪', look: 'modern', desc: 'Countdown to the next event, announcements, schedule, about and a giving button.',
      widgets: [
        W('announcement', 'side', { text: 'Welcome! Check the schedule below for upcoming events.', style: 'info', active: true }),
        W('countdown', 'side', { label: 'Next event in', target: '+1440m', done: 'Starting now' }),
        W('schedule', 'side'),
        W('about', 'side', { title: 'About {name}', text: 'Tell visitors who you are and what this channel is for.' }),
        W('support', 'side', { label: 'Give / support us' }), W('links', 'side', { title: 'Connect' }), W('stats', 'side'),
      ],
    },
    shopping: {
      name: 'Shopping Channel', icon: '🛍️', look: 'cable', desc: 'Deal countdown, featured-item lower third, sponsors, deals crawl and a giveaway.',
      widgets: [
        W('bug', 'overlay', { pos: 'tr' }),
        W('countdown', 'overlay', { label: 'Deal ends in', target: '+30m', done: 'Deal over' }),
        W('lowerthird', 'overlay', { line1: 'Featured item', line2: 'Today only — ask in chat', visible: true }),
        W('ticker', 'overlay', { label: 'DEALS', items: ['Add today\'s deals here', 'Free shipping on orders over $50'] }),
        W('sponsor', 'side', { name: 'Featured seller', text: 'Describe the offer' }),
        W('giveaway', 'side', { prize: 'A mystery gift' }), W('poll', 'side', { question: 'Which item next?', options: ['Item one', 'Item two', 'Item three'] }),
        W('reactions', 'side'), W('schedule', 'side'), W('support', 'side', { label: 'Shop now' }),
      ],
    },
    talkshow: {
      name: 'Talk Show', icon: '🎙️', look: 'modern', desc: 'Guest lower thirds, hot-take polls, giveaways and audience reactions.',
      widgets: [
        W('lowerthird', 'overlay', { line1: 'Guest Name', line2: 'Guest title', visible: true }),
        W('nownext', 'overlay', { now: 'Tonight: {name}', next: '', nextTime: '' }),
        W('poll', 'side', { question: 'Hot take: agree or disagree?', options: ['Agree', 'Disagree'] }),
        W('reactions', 'side', { title: 'Applause' }), W('giveaway', 'side'),
        W('about', 'side', { title: 'About the show', text: 'What is this show about?' }), W('schedule', 'side'), W('stats', 'side'),
      ],
    },
    minimal: {
      name: 'Minimal', icon: '▫️', look: 'modern', desc: 'Just the video and chat — add widgets only when you want them.',
      widgets: [W('stats', 'side')],
    },
  };

  function instantiate(id, net) {
    const t = templates[id] || templates.classic;
    const name = (net && net.name) || 'My Network';
    const sub = (v) => {
      if (typeof v === 'string') {
        const s = v.replace(/\{name\}/g, name);
        const m = s.match(/^\+(\d+)m$/);
        return m ? new Date(Date.now() + parseInt(m[1], 10) * 60000).toISOString() : s;
      }
      if (Array.isArray(v)) return v.map(sub);
      if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, sub(x)]));
      return v;
    };
    return { look: t.look, widgets: t.widgets.map((w) => ({ type: w.type, place: w.place, cfg: sub(w.cfg) })) };
  }

  return { types, TZ, REACTIONS, PLACES, LOOKS, templates, instantiate, defaults, clone };
});
