'use strict';
(() => {
  const { $, api, config, look } = SN;
  config().then((c) => { $('#siteName').textContent = c.siteName; });
  look.init('cable'); // the guide defaults to the cable look; viewers can switch it off

  async function refresh() {
    try { Guide.render($('#glist'), await api('/api/networks')); } catch {}
  }
  refresh();
  setInterval(refresh, 5000);

  const f = new Intl.DateTimeFormat([], { weekday: 'short', hour: 'numeric', minute: '2-digit' });
  const tick = () => { $('#gclock').textContent = f.format(new Date()); };
  tick();
  setInterval(tick, 15000);
})();
