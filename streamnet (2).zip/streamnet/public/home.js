'use strict';
(() => {
  const { $, api, config, toast, keys, setKey, look, chLabel } = SN;
  const S = window.WidgetSchema;

  config().then((c) => {
    $('#siteName').textContent = c.siteName;
    document.title = c.siteName + ' — run your own TV network';
    look.init(c.defaultLook);
  }).catch(() => look.init('modern'));

  function card(n, studio) {
    const a = document.createElement('a');
    a.className = 'card';
    a.href = (studio ? '/studio/' : '/n/') + n.slug;
    const screen = document.createElement('div');
    screen.className = 'screen';
    screen.style.setProperty('--c', n.color);
    const bug = document.createElement('div');
    bug.className = 'bug';
    bug.textContent = n.name;
    const badge = document.createElement('span');
    badge.className = 'badge' + (n.live ? '' : ' off');
    badge.textContent = n.live ? 'LIVE' : 'OFF AIR';
    const ch = document.createElement('span');
    ch.className = 'chnum';
    ch.textContent = chLabel(n.channel);
    screen.append(bug, badge, ch);
    if (n.live) {
      const v = document.createElement('span');
      v.className = 'badge n';
      v.textContent = n.viewers + ' watching';
      screen.appendChild(v);
    }
    const meta = document.createElement('div');
    meta.className = 'meta';
    const b = document.createElement('b');
    b.textContent = studio ? 'Open studio — ' + n.name : (n.live && n.title) || n.name;
    const s = document.createElement('span');
    s.textContent = n.tagline || (n.live ? n.name : 'Not live right now');
    meta.append(b, s);
    a.append(screen, meta);
    return a;
  }

  function fill(el, list, emptyMsg, studio) {
    el.textContent = '';
    if (!list.length) {
      const d = document.createElement('div');
      d.className = 'empty';
      d.style.gridColumn = '1/-1';
      d.textContent = emptyMsg;
      el.appendChild(d);
      return;
    }
    list.forEach((n) => el.appendChild(card(n, studio)));
  }

  async function refresh() {
    try {
      const all = await api('/api/networks');
      fill($('#liveGrid'), all.filter((n) => n.live), 'Nobody is live right now. Be the first!');
      fill($('#allGrid'), all, 'No networks yet. Create the first one.');
      const mine = Object.keys(keys());
      const mineNets = all.filter((n) => mine.includes(n.slug));
      $('#mineSec').hidden = !mineNets.length;
      if (mineNets.length) fill($('#mine'), mineNets, '', true);
    } catch (e) { /* offline; try again next tick */ }
  }
  refresh();
  setInterval(refresh, 5000);

  // ----- create dialog -----
  const dlg = $('#dlg');
  const sel = $('#nTpl');
  Object.entries(S.templates).forEach(([id, t]) => {
    const o = document.createElement('option');
    o.value = id;
    o.textContent = t.icon + '  ' + t.name;
    sel.appendChild(o);
  });
  function tplChanged() {
    const t = S.templates[sel.value];
    $('#tplDesc').textContent = t.desc;
    $('#nCable').checked = t.look === 'cable';
  }
  sel.addEventListener('change', tplChanged);
  tplChanged();

  const open = () => {
    $('#step1').hidden = false;
    $('#step2').hidden = true;
    $('#err').textContent = '';
    dlg.showModal();
    $('#nName').focus();
  };
  $('#openCreate').onclick = open;
  $('#openCreate2').onclick = open;
  $('#cancel').onclick = () => dlg.close();

  $('#createForm').addEventListener('submit', async (e) => {
    if ($('#step2').hidden === false) return; // let dialog close normally
    e.preventDefault();
    $('#go').disabled = true;
    $('#err').textContent = '';
    try {
      const r = await api('/api/networks', {
        method: 'POST',
        body: {
          name: $('#nName').value, tagline: $('#nTag').value, color: $('#nColor').value,
          template: sel.value, look: $('#nCable').checked ? 'cable' : 'modern',
        },
      });
      setKey(r.slug, r.key);
      $('#keyOut').textContent = r.key;
      $('#toStudio').href = '/studio/' + r.slug;
      $('#step1').hidden = true;
      $('#step2').hidden = false;
      refresh();
    } catch (err) {
      $('#err').textContent = err.message;
    } finally {
      $('#go').disabled = false;
    }
  });

  $('#copyKey').onclick = async () => {
    try {
      await navigator.clipboard.writeText($('#keyOut').textContent);
      toast('Key copied');
    } catch { toast('Select the key and copy it manually'); }
  };
})();
