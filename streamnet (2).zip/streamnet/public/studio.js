'use strict';
(() => {
  const { $, api, config, toast, getKey, setKey, socket, addChat, now } = SN;
  const S = window.WidgetSchema;
  const slug = location.pathname.split('/')[2];
  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

  let key = getKey(slug);
  let iceServers = [{ urls: 'stun:stun.l.google.com:19302' }];
  let stream = null;        // what we're sending
  let source = 'camera';
  let sock = null;
  let live = false;
  let send = () => {};
  let viewers = 0;
  let liveStarted = 0;
  const peers = new Map();  // viewerId -> RTCPeerConnection
  let audioCtx = null;
  const extraStops = [];    // things to stop when source changes (mic for screen mode, etc.)

  // widget editor state
  let net = null;           // last snapshot from the server
  let widgets = [];         // editable copy
  let runtime = {};
  let dirty = false;
  let openId = null;
  let serverIds = new Set();

  $('#viewLink').href = '/n/' + slug;
  $('#shareUrl').value = location.origin + '/n/' + slug;
  config().then((c) => { iceServers = c.iceServers; $('#siteName').textContent = c.siteName; });

  const host = Widgets.createHost({
    side: $('#prevSide'),
    below: $('#prevBelow'),
    zones: { tl: $('#z-tl'), tc: $('#z-tc'), tr: $('#z-tr'), bl: $('#z-bl'), br: $('#z-br'), ticker: $('#z-ticker') },
    floaters: $('#floaters'),
    studio: true,
    send: () => {},
    chatName: () => (net ? net.name : 'host'),
  });
  const pushStats = () => host.setStats({ viewers, live, startedAt: liveStarted });
  const newId = () => Array.from(crypto.getRandomValues(new Uint8Array(4)), (b) => b.toString(16).padStart(2, '0')).join('');
  const put = (partial) => api('/api/networks/' + slug, { method: 'PUT', body: { key, ...partial } });

  function setScope(look) {
    $('#prevScope').classList.toggle('cable-scope', look === 'cable');
    $('#prevWrap').classList.toggle('cable-scope', look === 'cable');
  }
  let previewTimer = null;
  function schedulePreview() { clearTimeout(previewTimer); previewTimer = setTimeout(applyPreview, 150); }
  function applyPreview() {
    if (net) host.setNet(net);
    host.setWidgets(widgets);
    host.setAllRuntime(runtime);
    pushStats();
  }
  function markDirty(on = true) {
    dirty = on;
    $('#dirty').textContent = on ? '● Unsaved changes' : '';
    $('#saveWidgets').disabled = !on;
  }

  // ---------- gate ----------
  async function verify(k) {
    try { return (await api('/api/networks/' + slug + '/verify', { method: 'POST', body: { key: k } })).ok; }
    catch { return false; }
  }
  async function enter() {
    $('#gate').hidden = true;
    $('#studio').hidden = false;
    $('#keyShow').textContent = key;
    try {
      net = await api('/api/networks/' + slug);
    } catch {
      $('#studio').hidden = true;
      $('#gate').hidden = false;
      $('#gateErr').textContent = 'This network does not exist.';
      return;
    }
    adopt(net);
    $('#liveTitle').value = net.name + ' LIVE';
    (net.lineup.length ? net.lineup : [{ when: '', title: '' }]).forEach(addRow);
    buildGallery();
    buildTemplates();
    setInterval(pollRuntime, 3000);
  }
  // take a fresh server snapshot as the new truth
  function adopt(n) {
    net = n;
    widgets = S.clone(n.widgets);
    runtime = n.runtime || {};
    serverIds = new Set(widgets.map((w) => w.id));
    document.title = n.name + ' — studio';
    $('#nName').value = n.name;
    $('#nTag').value = n.tagline;
    $('#nChan').value = n.channel;
    $('#nColor').value = n.color;
    $('#nLook').value = n.look;
    setScope(n.look);
    markDirty(false);
    renderList();
    renderControls(true);
    applyPreview();
  }
  async function init() {
    if (key && (await verify(key))) return enter();
    $('#gate').hidden = false;
  }
  $('#keyGo').onclick = async () => {
    const k = $('#keyIn').value.trim();
    if (await verify(k)) { key = k; setKey(slug, k); enter(); }
    else $('#gateErr').textContent = 'That key is not right.';
  };
  $('#keyIn').addEventListener('keydown', (e) => e.key === 'Enter' && $('#keyGo').click());

  // ---------- capture ----------
  const canCapture = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  if (!canCapture) $('#warn').textContent = 'Camera and screen capture need a secure connection (HTTPS) or localhost.';
  if (!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia)) $('#srcScreen').hidden = true;

  function stopCapture() {
    if (stream) stream.getTracks().forEach((t) => t.stop());
    extraStops.splice(0).forEach((t) => t.stop());
    if (audioCtx) { audioCtx.close().catch(() => {}); audioCtx = null; }
    stream = null;
  }

  async function mixAudio(tracks) {
    if (tracks.length <= 1) return tracks[0] || null;
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const dest = audioCtx.createMediaStreamDestination();
    tracks.forEach((t) => audioCtx.createMediaStreamSource(new MediaStream([t])).connect(dest));
    return dest.stream.getAudioTracks()[0];
  }

  async function capture(kind) {
    let video, audio = [];
    if (kind === 'screen') {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: { ideal: 30 } }, audio: true });
      video = s.getVideoTracks()[0];
      audio = s.getAudioTracks();
      extraStops.push(...audio);
      try {
        const mic = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
        audio.push(mic.getAudioTracks()[0]);
        extraStops.push(mic.getAudioTracks()[0]);
      } catch { /* screen without mic is fine */ }
      video.onended = onScreenEnded;
    } else {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } },
        audio: { echoCancellation: true, noiseSuppression: true },
      });
      video = s.getVideoTracks()[0];
      audio = s.getAudioTracks();
    }
    const a = await mixAudio(audio);
    const out = new MediaStream([video]);
    if (a) out.addTrack(a);
    return out;
  }

  async function useSource(kind) {
    if (!canCapture) return;
    const old = stream;
    const oldExtra = extraStops.splice(0);
    const oldCtx = audioCtx;
    audioCtx = null;
    let next;
    try {
      next = await capture(kind);
    } catch (e) {
      extraStops.push(...oldExtra);
      audioCtx = oldCtx;
      toast(e && e.name === 'NotAllowedError' ? 'Permission was denied.' : 'Could not start that source.');
      return false;
    }
    source = kind;
    stream = next;
    $('#preview').srcObject = stream;
    $('#noSource').hidden = true;
    $('#micBtn').disabled = $('#camBtn').disabled = false;
    syncToggles();
    for (const pc of peers.values()) {
      for (const sender of pc.getSenders()) {
        const t = sender.track && stream.getTracks().find((n) => n.kind === sender.track.kind);
        if (t) sender.replaceTrack(t).catch(() => {});
      }
    }
    if (old) old.getTracks().forEach((t) => t.stop());
    oldExtra.forEach((t) => t.stop());
    if (oldCtx) oldCtx.close().catch(() => {});
    $('#srcCam').classList.toggle('on', kind === 'camera');
    $('#srcScreen').classList.toggle('on', kind === 'screen');
    return true;
  }

  async function onScreenEnded() {
    toast('Screen sharing stopped — switching to camera.');
    if (!(await useSource('camera')) && live) endLive();
  }

  function syncToggles() {
    const a = stream && stream.getAudioTracks()[0];
    const v = stream && stream.getVideoTracks()[0];
    $('#micBtn').textContent = a && !a.enabled ? '🔇 Mic muted' : '🎤 Mic on';
    $('#camBtn').textContent = v && !v.enabled ? '🚫 Video off' : '📷 Video on';
  }
  $('#micBtn').onclick = () => { const a = stream && stream.getAudioTracks()[0]; if (a) { a.enabled = !a.enabled; syncToggles(); } };
  $('#camBtn').onclick = () => { const v = stream && stream.getVideoTracks()[0]; if (v) { v.enabled = !v.enabled; syncToggles(); } };
  $('#srcCam').onclick = () => useSource('camera');
  $('#srcScreen').onclick = () => useSource('screen');

  // ---------- peers ----------
  function applyBitrate(pc) {
    const max = parseInt($('#quality').value, 10);
    pc.getSenders().forEach((s) => {
      if (!s.track || s.track.kind !== 'video') return;
      try {
        const p = s.getParameters();
        if (!p.encodings || !p.encodings.length) p.encodings = [{}];
        p.encodings[0].maxBitrate = max;
        s.setParameters(p).catch(() => {});
      } catch {}
    });
  }
  $('#quality').onchange = () => peers.forEach(applyBitrate);

  async function addPeer(id) {
    if (!stream || peers.has(id)) return;
    const pc = new RTCPeerConnection({ iceServers });
    peers.set(id, pc);
    stream.getTracks().forEach((t) => pc.addTrack(t, stream));
    pc.onicecandidate = (e) => e.candidate && send({ type: 'signal', to: id, data: { candidate: e.candidate } });
    pc.onconnectionstatechange = () => {
      if (['failed', 'closed'].includes(pc.connectionState)) dropPeer(id);
    };
    try {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      applyBitrate(pc);
      send({ type: 'signal', to: id, data: { sdp: pc.localDescription } });
    } catch (e) { dropPeer(id); }
  }
  function dropPeer(id) {
    const pc = peers.get(id);
    if (pc) { pc.onicecandidate = pc.onconnectionstatechange = null; try { pc.close(); } catch {} }
    peers.delete(id);
  }
  const pendingIce = new Map();
  async function onViewerSignal(id, data) {
    const pc = peers.get(id);
    if (!pc) return;
    try {
      if (data.sdp) {
        await pc.setRemoteDescription(data.sdp);
        for (const c of pendingIce.get(id) || []) await pc.addIceCandidate(c).catch(() => {});
        pendingIce.delete(id);
      } else if (data.candidate) {
        if (pc.remoteDescription) await pc.addIceCandidate(data.candidate);
        else pendingIce.set(id, [...(pendingIce.get(id) || []), data.candidate]);
      }
    } catch {}
  }

  // ---------- go live / end ----------
  function setLiveUi(on) {
    live = on;
    liveStarted = on ? now() : 0;
    $('#goLive').hidden = on;
    $('#endLive').hidden = !on;
    $('#badge').textContent = on ? 'LIVE' : 'OFF AIR';
    $('#badge').className = on ? 'badge' : 'badge off';
    $('#chatText').disabled = !on;
    $('#count').hidden = !on;
    $('#stat').textContent = on ? 'You are live — anyone with your link can watch.' : '';
    if (!on) viewers = 0;
    pushStats();
  }

  $('#goLive').onclick = async () => {
    $('#warn').textContent = '';
    if (dirty && !confirm('You have unpublished widget changes. Go live anyway? (Viewers will see the last published version.)')) return;
    if (!stream && !(await useSource(source))) return;
    $('#goLive').disabled = true;
    sock = socket(
      (s) => {
        send = s;
        peers.forEach((_, id) => dropPeer(id)); // fresh start after any reconnect
        s({ type: 'broadcast', slug, key, title: $('#liveTitle').value });
      },
      (m) => {
        switch (m.type) {
          case 'live-ok': setLiveUi(true); $('#goLive').disabled = false; break;
          case 'viewer-joined': addPeer(m.id); break;
          case 'viewer-left': dropPeer(m.id); break;
          case 'signal': onViewerSignal(m.from, m.data); break;
          case 'count': viewers = m.n; $('#count').textContent = m.n + ' watching'; pushStats(); break;
          case 'chat': addChat($('#log'), m); break;
          case 'reaction': host.react(m.emoji); break;
          case 'runtime': runtime[m.id] = m.state; host.setRuntime(m.id, m.state); renderControls(false); break;
          case 'kicked':
            toast('Broadcast started from another window.');
            teardown();
            break;
          case 'error':
            $('#warn').textContent = m.error || 'Could not go live.';
            teardown();
            break;
        }
      }
    );
  };

  function teardown() {
    if (sock) { sock.close(); sock = null; }
    peers.forEach((_, id) => dropPeer(id));
    setLiveUi(false);
    $('#goLive').disabled = false;
  }
  function endLive() {
    send({ type: 'stop' });
    teardown();
    stopCapture();
    $('#preview').srcObject = null;
    $('#noSource').hidden = false;
    $('#micBtn').disabled = $('#camBtn').disabled = true;
  }
  $('#endLive').onclick = endLive;
  window.addEventListener('beforeunload', (e) => { if (live || dirty) { e.preventDefault(); e.returnValue = ''; } });

  $('#liveTitle').addEventListener('change', () => live && send({ type: 'title', title: $('#liveTitle').value }));

  $('#chatForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const t = $('#chatText').value.trim();
    if (t && live) send({ type: 'chat', text: t });
    $('#chatText').value = '';
  });

  $('#copyUrl').onclick = async () => {
    try { await navigator.clipboard.writeText($('#shareUrl').value); toast('Link copied'); }
    catch { $('#shareUrl').select(); toast('Press Ctrl/Cmd+C to copy'); }
  };

  // ---------- tabs ----------
  document.querySelectorAll('.tabs button').forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
      document.querySelectorAll('.tabpane').forEach((p) => { p.hidden = p.id !== 'tab-' + b.dataset.tab; });
    };
  });

  // ---------- widget list ----------
  function buildGallery() {
    const g = $('#gallery');
    g.textContent = '';
    Object.entries(S.types).forEach(([type, def]) => {
      const b = h('button', 'gcard');
      b.type = 'button';
      b.append(h('span', 'gi', def.icon), h('b', null, def.label), h('span', 'gd', def.desc));
      b.onclick = () => {
        if (widgets.length >= 30) return toast('That is the maximum of 30 widgets.');
        const w = { id: newId(), type, place: def.places[0], cfg: S.defaults(type) };
        widgets.push(w);
        openId = w.id;
        markDirty();
        renderList();
        schedulePreview();
        $('#gallery').hidden = true;
        const card = document.querySelector('.wcard.open');
        if (card) card.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      };
      g.appendChild(b);
    });
  }
  $('#addToggle').onclick = () => { $('#gallery').hidden = !$('#gallery').hidden; };

  function renderList() {
    const list = $('#wlist');
    list.textContent = '';
    if (!widgets.length) list.appendChild(h('div', 'empty', 'No widgets yet. Add one, or pick a template.'));
    widgets.forEach((w, i) => {
      const def = S.types[w.type];
      const card = h('div', 'wcard' + (openId === w.id ? ' open' : ''));
      const head = h('div', 'wcard-head');
      const t = h('div', 'wt');
      t.append(h('span', 'wi', def.icon), h('b', null, def.label));
      const hint = h('span', 'whint', Widgets.needs(w));
      const place = h('select');
      place.setAttribute('aria-label', 'Where it shows');
      def.places.forEach((p) => { const o = h('option', null, S.PLACES[p]); o.value = p; place.appendChild(o); });
      place.value = w.place;
      place.disabled = def.places.length < 2;
      place.onchange = () => { w.place = place.value; markDirty(); schedulePreview(); };
      const mk = (label, aria, fn, dis) => { const b = h('button', 'btn small', label); b.type = 'button'; b.setAttribute('aria-label', aria); b.disabled = !!dis; b.onclick = fn; return b; };
      const up = mk('↑', 'Move up', () => { [widgets[i - 1], widgets[i]] = [widgets[i], widgets[i - 1]]; markDirty(); renderList(); schedulePreview(); }, i === 0);
      const down = mk('↓', 'Move down', () => { [widgets[i + 1], widgets[i]] = [widgets[i], widgets[i + 1]]; markDirty(); renderList(); schedulePreview(); }, i === widgets.length - 1);
      const edit = mk(openId === w.id ? 'Close' : 'Edit', 'Edit settings', () => { openId = openId === w.id ? null : w.id; renderList(); });
      const del = mk('✕', 'Delete widget', () => { widgets.splice(i, 1); if (openId === w.id) openId = null; markDirty(); renderList(); schedulePreview(); });
      head.append(t, hint, place, up, down, edit, del);
      card.appendChild(head);
      if (openId === w.id) {
        card.appendChild(Widgets.form(w.type, w.cfg, (cfg) => {
          w.cfg = cfg;
          hint.textContent = Widgets.needs(w);
          markDirty();
          schedulePreview();
        }));
      }
      list.appendChild(card);
    });
  }

  $('#saveWidgets').onclick = async () => {
    try {
      const res = await put({ widgets });
      adopt(res);
      toast('Published ✓ — viewers see it now');
    } catch (e) { toast(e.message); }
  };

  // ---------- templates ----------
  function buildTemplates() {
    const g = $('#tgrid');
    g.textContent = '';
    Object.entries(S.templates).forEach(([id, t]) => {
      const card = h('div', 'tcard');
      const top = h('div', 'ttop');
      top.append(h('span', 'ti', t.icon), h('b', null, t.name), h('span', 'tlook', t.look === 'cable' ? 'Cable look' : 'Modern look'));
      const chips = h('div', 'tchips');
      const counts = {};
      t.widgets.forEach((w) => { counts[w.type] = (counts[w.type] || 0) + 1; });
      Object.entries(counts).forEach(([type, n]) => chips.appendChild(h('span', 'chipw', S.types[type].icon + ' ' + S.types[type].label + (n > 1 ? ' ×' + n : ''))));
      const use = h('button', 'btn primary small', 'Use this template');
      use.type = 'button';
      use.onclick = async () => {
        if (widgets.length && !confirm('Replace your current widgets with the “' + t.name + '” template?')) return;
        const inst = S.instantiate(id, net);
        try {
          const res = await put({ widgets: inst.widgets.map((w) => ({ ...w, id: newId() })), look: inst.look });
          openId = null;
          adopt(res);
          toast('Template applied ✓');
          document.querySelector('.tabs [data-tab="widgets"]').click();
          if (res.look === 'cable') toast('Cable TV look is now your default.');
        } catch (e) { toast(e.message); }
      };
      card.append(top, h('p', 'dim', t.desc), chips, use);
      g.appendChild(card);
    });
  }

  // ---------- look & channel ----------
  $('#nLook').onchange = () => setScope($('#nLook').value);
  $('#saveLook').onclick = async () => {
    $('#lookErr').textContent = '';
    try {
      const res = await put({
        name: $('#nName').value, tagline: $('#nTag').value, color: $('#nColor').value,
        look: $('#nLook').value, channel: parseInt($('#nChan').value, 10),
      });
      // keep unsaved widget edits; only refresh the network facts
      net = res;
      setScope(res.look);
      host.setNet(res);
      document.title = res.name + ' — studio';
      toast('Saved ✓');
    } catch (e) { $('#lookErr').textContent = e.message; }
  };

  // ---------- live controls ----------
  const ctl = {
    cfg: (id) => widgets.find((w) => w.id === id).cfg,
    rt: (id) => runtime[id],
    now,
    async patch(id, patch) {
      try {
        const r = await api('/api/networks/' + slug + '/widget-patch', { method: 'POST', body: { key, id, patch } });
        const w = widgets.find((x) => x.id === id);
        if (w) for (const k of Object.keys(patch)) w.cfg[k] = r.widget.cfg[k];
        runtime = r.runtime;
        schedulePreview();
        renderControls(true);
      } catch (e) { toast(e.message); }
    },
    async action(id, action) {
      try {
        const r = await api('/api/networks/' + slug + '/widget-action', { method: 'POST', body: { key, id, action } });
        runtime[id] = r.state;
        host.setRuntime(id, r.state);
        renderControls(true);
      } catch (e) { toast(e.message); }
    },
  };
  function renderControls(force) {
    const box = $('#liveCtl');
    const ae = document.activeElement;
    if (!force && box.contains(ae) && ae.tagName === 'INPUT' && ae.value) return; // don't wipe what they're typing
    // remember what is typed (and where the cursor is) so a rebuild never eats it
    const keyOf = (i) => (i.closest('.ctl') ? i.closest('.ctl').dataset.wid : '') + '|' + i.placeholder;
    const typed = new Map([...box.querySelectorAll('input')].map((i) => [keyOf(i), i.value]));
    const focusKey = ae && box.contains(ae) && ae.tagName === 'INPUT' ? keyOf(ae) : null;
    box.textContent = '';
    const list = widgets.filter((w) => serverIds.has(w.id) && Widgets.hasControls(w.type));
    list.forEach((w) => { const el = Widgets.controls(w, ctl); if (el) box.appendChild(el); });
    box.querySelectorAll('input').forEach((i) => {
      const k = keyOf(i);
      if (typed.get(k)) i.value = typed.get(k);
      if (k === focusKey) i.focus();
    });
    if (!list.length) box.appendChild(h('p', 'dim small', 'Add a scoreboard, poll, lower third, timer, giveaway, ticker, now & next or announcement widget and its live buttons appear here.'));
    if (widgets.some((w) => !serverIds.has(w.id) && Widgets.hasControls(w.type))) box.appendChild(h('p', 'dim small', 'Publish your widgets to get live buttons for the new ones.'));
  }
  let lastRt = '';
  async function pollRuntime() {
    if (document.hidden || !net) return;
    try {
      const n = await api('/api/networks/' + slug);
      if (!live) { viewers = n.viewers; pushStats(); }
      const sig = JSON.stringify(n.runtime);
      if (sig !== lastRt) {
        lastRt = sig;
        runtime = n.runtime;
        host.setAllRuntime(runtime);
        renderControls(false);
      }
    } catch {}
  }

  // ---------- schedule ----------
  function addRow(r = { when: '', title: '' }) {
    if ($('#rows').children.length >= 20) return;
    const row = h('div', 'lineup-row');
    const w = h('input'); w.type = 'text'; w.maxLength = 30; w.placeholder = 'Fri 8pm'; w.value = r.when || ''; w.setAttribute('aria-label', 'Time');
    const t = h('input'); t.type = 'text'; t.maxLength = 70; t.placeholder = 'Show title'; t.value = r.title || ''; t.setAttribute('aria-label', 'Show title');
    const x = h('button', 'btn small', '✕'); x.type = 'button'; x.setAttribute('aria-label', 'Remove');
    x.onclick = () => row.remove();
    row.append(w, t, x);
    $('#rows').appendChild(row);
  }
  $('#addRow').onclick = () => addRow();
  $('#saveGuide').onclick = async () => {
    const lineup = [...$('#rows').children].map((r) => ({ when: r.children[0].value, title: r.children[1].value }));
    try {
      const res = await put({ lineup });
      net = res;
      host.setNet(res);
      toast('Schedule saved ✓');
    } catch (e) { toast(e.message); }
  };

  init();
})();
