'use strict';

const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const Schema = require('./public/widget-schema.js');

// ---------- config ----------
const PORT = parseInt(process.env.PORT || '3000', 10);
const SITE_NAME = process.env.SITE_NAME || 'StreamNet';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const MAX_VIEWERS = parseInt(process.env.MAX_VIEWERS_PER_STREAM || '25', 10);
const MAX_NETWORKS = parseInt(process.env.MAX_NETWORKS || '500', 10);
const DEFAULT_LOOK = process.env.DEFAULT_LOOK === 'cable' ? 'cable' : 'modern';
const TRUST_PROXY = !!process.env.TRUST_PROXY;
const TURN_URL = process.env.TURN_URL || '';
const TURN_USER = process.env.TURN_USER || '';
const TURN_PASS = process.env.TURN_PASS || '';
const MAX_WIDGETS = 30;

fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, 'networks.json');

// ---------- helpers ----------
const RESERVED = new Set(['api', 'ws', 'n', 'studio', 'static', 'assets', 'admin', 'guide']);
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
function keyOk(net, key) {
  if (!net || typeof key !== 'string') return false;
  const a = Buffer.from(sha(key), 'hex');
  const b = Buffer.from(net.keyHash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function slugify(s) {
  return String(s)
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^\w\s-]/g, '')
    .trim()
    .replace(/[\s_]+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 32)
    .replace(/^-|-$/g, '');
}
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n);
const cleanMulti = (s, n) =>
  String(s == null ? '' : s).replace(/\r/g, '').replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, ' ').replace(/\n{3,}/g, '\n\n').trim().slice(0, n);
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;
const URL_RE = /^https?:\/\/[^\s<>"'\\]{3,300}$/i;
const LOOKS = new Set(['modern', 'cable']);

// ---------- widget validation (driven by the shared schema) ----------
function sanField(f, v) {
  if (v === undefined) v = Schema.clone(f.def);
  switch (f.t) {
    case 'text': return clean(v, f.max || 100);
    case 'textarea': return cleanMulti(v, f.max || 500);
    case 'url': { const s = clean(v, 300); return URL_RE.test(s) ? s : ''; }
    case 'number': {
      let n = Number(v);
      if (!Number.isFinite(n)) n = Number.isFinite(f.def) ? f.def : 0;
      if (f.int) n = Math.round(n);
      return Math.min(f.maxv == null ? 1e9 : f.maxv, Math.max(f.min == null ? -1e9 : f.min, n));
    }
    case 'bool': return v === true || v === 'true' ? true : v === false || v === 'false' ? false : !!f.def;
    case 'select': return f.opts.some((o) => o[0] === v) ? v : f.def;
    case 'color': return COLOR_RE.test(v) ? v : f.def;
    case 'datetime': {
      if (!v) return '';
      const t = Date.parse(v);
      return Number.isFinite(t) ? new Date(t).toISOString() : '';
    }
    case 'list': {
      const arr = Array.isArray(v) ? v.slice(0, f.maxItems || 10) : [];
      if (f.of) return arr.map((x) => sanField(f.of, x)).filter(Boolean);
      return arr
        .map((row) => {
          const o = {};
          for (const sf of f.fields) o[sf.k] = sanField(sf, row && typeof row === 'object' ? row[sf.k] : '');
          return o;
        })
        .filter((o) => Object.values(o).every(Boolean));
    }
    default: return undefined;
  }
}
const hasType = (t) => typeof t === 'string' && Object.hasOwn(Schema.types, t);
function sanCfg(type, cfg) {
  const out = {};
  for (const f of Schema.types[type].fields) out[f.k] = sanField(f, cfg && typeof cfg === 'object' ? cfg[f.k] : undefined);
  return out;
}
function sanWidgets(list) {
  const out = [];
  const ids = new Set();
  for (const w of (Array.isArray(list) ? list : []).slice(0, MAX_WIDGETS)) {
    if (!w || !hasType(w.type)) continue;
    const def = Schema.types[w.type];
    let id = typeof w.id === 'string' && /^[a-z0-9]{6,12}$/.test(w.id) && !ids.has(w.id) ? w.id : null;
    while (!id || ids.has(id)) id = crypto.randomBytes(4).toString('hex');
    ids.add(id);
    out.push({ id, type: w.type, place: def.places.includes(w.place) ? w.place : def.places[0], cfg: sanCfg(w.type, w.cfg) });
  }
  return out;
}

// ---------- tiny persistence ----------
/** slug -> network (Map, so odd slugs can't touch prototypes) */
const networks = new Map();
try {
  for (const [k, v] of Object.entries(JSON.parse(fs.readFileSync(DB_FILE, 'utf8')))) networks.set(k, v);
} catch { /* first run */ }

function nextChannel() {
  let max = 1;
  for (const n of networks.values()) if (Number.isInteger(n.channel) && n.channel > max) max = n.channel;
  return Math.min(max + 1, 999);
}
// upgrade networks saved by older versions
(function migrate() {
  const used = new Set();
  const list = [...networks.values()].sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
  for (const n of list) {
    if (Number.isInteger(n.channel) && !used.has(n.channel)) used.add(n.channel);
    else n.channel = null;
  }
  for (const n of list) {
    if (!LOOKS.has(n.look)) n.look = DEFAULT_LOOK;
    if (!Array.isArray(n.widgets)) n.widgets = sanWidgets(Schema.instantiate('classic', n).widgets);
    if (!n.channel) { n.channel = nextChannel(); used.add(n.channel); }
  }
})();

let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const tmp = DB_FILE + '.tmp';
    fs.writeFile(tmp, JSON.stringify(Object.fromEntries(networks), null, 2), (err) => {
      if (err) return console.error('save failed', err);
      fs.rename(tmp, DB_FILE, (e) => e && console.error('rename failed', e));
    });
  }, 200);
}

// ---------- live rooms ----------
/** @type {Map<string,{broadcaster:any,viewers:Map<string,any>,title:string,startedAt:number}>} */
const rooms = new Map();
function room(slug) {
  let r = rooms.get(slug);
  if (!r) {
    r = { broadcaster: null, viewers: new Map(), title: '', startedAt: 0 };
    rooms.set(slug, r);
  }
  return r;
}
const viewerCount = (slug) => (rooms.get(slug) ? rooms.get(slug).viewers.size : 0);

// ---------- per-stream interactive state (polls, giveaways) — in memory ----------
/** slug -> Map(widgetId -> state) */
const runtimes = new Map();
function rtState(net, w) {
  let m = runtimes.get(net.slug);
  if (!m) { m = new Map(); runtimes.set(net.slug, m); }
  const sig = w.type === 'poll' ? JSON.stringify([w.cfg.question, w.cfg.options]) : JSON.stringify(w.cfg.prize);
  let st = m.get(w.id);
  if (!st || st.sig !== sig) {
    const rev = st ? st.rev + 1 : 1;
    st = w.type === 'poll'
      ? { sig, rev, votes: new Array(w.cfg.options.length).fill(0), voters: new Map() }
      : { sig, rev, entries: new Map(), winner: '' };
    m.set(w.id, st);
  }
  return st;
}
function pubState(w, st) {
  if (w.type === 'poll') return { counts: st.votes, total: st.votes.reduce((a, b) => a + b, 0), rev: st.rev };
  return { count: st.entries.size, winner: st.winner, rev: st.rev };
}
function runtimeFor(net) {
  const out = {};
  for (const w of net.widgets) if (w.type === 'poll' || w.type === 'giveaway') out[w.id] = pubState(w, rtState(net, w));
  return out;
}
const rtQueue = new Map();
let rtTimer = null;
function queueRuntime(slug, id) {
  let s = rtQueue.get(slug);
  if (!s) { s = new Set(); rtQueue.set(slug, s); }
  s.add(id);
  if (!rtTimer) rtTimer = setTimeout(flushRuntime, 250);
}
function flushRuntime() {
  rtTimer = null;
  for (const [slug, ids] of rtQueue) {
    const net = networks.get(slug);
    if (!net) continue;
    for (const id of ids) {
      const w = net.widgets.find((x) => x.id === id);
      if (w) toRoom(slug, { type: 'runtime', id, state: pubState(w, rtState(net, w)) });
    }
  }
  rtQueue.clear();
}
function gcRuntime(net) {
  const m = runtimes.get(net.slug);
  if (m) for (const id of [...m.keys()]) if (!net.widgets.some((w) => w.id === id)) m.delete(id);
}

function publicNet(n, full) {
  const r = rooms.get(n.slug);
  const live = !!(r && r.broadcaster);
  const o = {
    slug: n.slug,
    name: n.name,
    tagline: n.tagline,
    color: n.color,
    look: n.look,
    channel: n.channel,
    live,
    title: live ? r.title : '',
    viewers: r ? r.viewers.size : 0,
    startedAt: live ? r.startedAt : 0,
    lineup: n.lineup,
  };
  if (full) {
    o.widgets = n.widgets;
    o.runtime = runtimeFor(n);
  }
  return o;
}
function pushNet(net) {
  toRoom(net.slug, { type: 'net', net: publicNet(net, true) });
}

// ---------- http ----------
const pub = path.join(__dirname, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

function baseHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' ws: wss:; frame-ancestors 'self'"
  );
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), display-capture=(self)');
}
function json(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function serveFile(req, res, rel) {
  const abs = path.resolve(pub, rel);
  if (abs !== pub && !abs.startsWith(pub + path.sep)) return json(res, 404, { error: 'Not found' });
  fs.stat(abs, (err, st) => {
    if (err || !st.isFile()) return json(res, 404, { error: 'Not found' });
    const ext = path.extname(abs).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': ext === '.html' ? 'no-cache' : 'no-cache',
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(abs).pipe(res);
  });
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 100 * 1024) {
        reject({ status: 413, error: 'Request too large' });
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        const v = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        resolve(v && typeof v === 'object' ? v : {});
      } catch { reject({ status: 400, error: 'Invalid JSON' }); }
    });
    req.on('error', () => reject({ status: 400, error: 'Bad request' }));
  });
}
function clientIp(req) {
  if (TRUST_PROXY) {
    const x = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (x) return x;
  }
  return req.socket.remoteAddress || 'unknown';
}

const createLog = new Map();
function createAllowed(ip) {
  const now = Date.now();
  const arr = (createLog.get(ip) || []).filter((t) => now - t < 3600e3);
  if (arr.length >= 5) return false;
  arr.push(now);
  createLog.set(ip, arr);
  return true;
}
setInterval(() => {
  const now = Date.now();
  for (const [ip, arr] of createLog) if (!arr.some((t) => now - t < 3600e3)) createLog.delete(ip);
}, 600e3).unref();

async function handleApi(req, res, p) {
  const m = req.method;

  if (p === '/api/config' && m === 'GET') {
    const iceServers = [{ urls: 'stun:stun.l.google.com:19302' }];
    if (TURN_URL) iceServers.push({ urls: TURN_URL, username: TURN_USER, credential: TURN_PASS });
    return json(res, 200, {
      siteName: SITE_NAME, iceServers, maxViewers: MAX_VIEWERS, defaultLook: DEFAULT_LOOK,
      serverTime: Date.now(), reactions: Schema.REACTIONS,
    });
  }

  if (p === '/api/networks' && m === 'GET') {
    const list = [...networks.values()].map((n) => publicNet(n, false));
    list.sort((a, b) => Number(b.live) - Number(a.live) || b.viewers - a.viewers || a.name.localeCompare(b.name));
    return json(res, 200, list);
  }

  if (p === '/api/networks' && m === 'POST') {
    const body = await readBody(req);
    if (networks.size >= MAX_NETWORKS) return json(res, 503, { error: 'This site is full right now.' });
    if (!createAllowed(clientIp(req))) return json(res, 429, { error: 'Too many networks created from your connection. Try again later.' });
    const name = clean(body.name, 40);
    const tagline = clean(body.tagline, 90);
    const color = COLOR_RE.test(body.color || '') ? body.color : '#e5484d';
    if (name.length < 2) return json(res, 400, { error: 'Give your network a name (2+ characters).' });
    let slug = slugify(name) || 'network';
    if (RESERVED.has(slug) || networks.has(slug)) slug = `${slug}-${crypto.randomBytes(2).toString('hex')}`.slice(0, 40);
    const key = crypto.randomBytes(18).toString('base64url');
    const tpl = typeof body.template === 'string' && Object.hasOwn(Schema.templates, body.template) ? body.template : 'classic';
    const inst = Schema.instantiate(tpl, { name });
    networks.set(slug, {
      slug, name, tagline, color, keyHash: sha(key), lineup: [], createdAt: Date.now(),
      look: LOOKS.has(body.look) ? body.look : inst.look,
      channel: nextChannel(),
      widgets: sanWidgets(inst.widgets),
    });
    save();
    return json(res, 201, { slug, key, channel: networks.get(slug).channel });
  }

  const mm = p.match(/^\/api\/networks\/([^/]+)(?:\/([a-z-]+))?$/);
  if (mm) {
    const net = networks.get(mm[1]);
    const sub = mm[2];
    if (!net) return json(res, 404, { error: 'Network not found' });

    if (!sub && m === 'GET') return json(res, 200, publicNet(net, true));

    if (sub === 'verify' && m === 'POST') {
      const body = await readBody(req);
      return json(res, 200, { ok: keyOk(net, body.key) });
    }

    if (!sub && m === 'PUT') {
      const body = await readBody(req);
      if (!keyOk(net, body.key)) return json(res, 403, { error: 'Wrong owner key.' });
      if (typeof body.name === 'string' && clean(body.name, 40).length >= 2) net.name = clean(body.name, 40);
      if (typeof body.tagline === 'string') net.tagline = clean(body.tagline, 90);
      if (COLOR_RE.test(body.color || '')) net.color = body.color;
      if (LOOKS.has(body.look)) net.look = body.look;
      if (body.channel !== undefined) {
        const c = parseInt(body.channel, 10);
        if (!(c >= 1 && c <= 999)) return json(res, 400, { error: 'Channel must be between 1 and 999.' });
        for (const o of networks.values()) if (o !== net && o.channel === c) return json(res, 409, { error: `Channel ${c} is already taken.` });
        net.channel = c;
      }
      if (Array.isArray(body.lineup)) {
        net.lineup = body.lineup
          .slice(0, 20)
          .map((r) => ({ when: clean(r && r.when, 30), title: clean(r && r.title, 70) }))
          .filter((r) => r.title);
      }
      if (Array.isArray(body.widgets)) {
        net.widgets = sanWidgets(body.widgets);
        gcRuntime(net);
      }
      save();
      pushNet(net);
      return json(res, 200, publicNet(net, true));
    }

    // live tweak of one widget (scores, lower third on/off, timers…)
    if (sub === 'widget-patch' && m === 'POST') {
      const body = await readBody(req);
      if (!keyOk(net, body.key)) return json(res, 403, { error: 'Wrong owner key.' });
      const w = net.widgets.find((x) => x.id === body.id);
      if (!w) return json(res, 404, { error: 'Widget not found' });
      w.cfg = sanCfg(w.type, { ...w.cfg, ...(body.patch && typeof body.patch === 'object' ? body.patch : {}) });
      save();
      pushNet(net);
      return json(res, 200, { widget: w, runtime: runtimeFor(net) });
    }

    if (sub === 'widget-action' && m === 'POST') {
      const body = await readBody(req);
      if (!keyOk(net, body.key)) return json(res, 403, { error: 'Wrong owner key.' });
      const w = net.widgets.find((x) => x.id === body.id);
      if (!w) return json(res, 404, { error: 'Widget not found' });
      const st = w.type === 'poll' || w.type === 'giveaway' ? rtState(net, w) : null;
      if (!st) return json(res, 400, { error: 'This widget has no actions.' });
      if (body.action === 'reset') {
        if (w.type === 'poll') { st.votes.fill(0); st.voters.clear(); } else { st.entries.clear(); st.winner = ''; }
        st.rev++;
      } else if (body.action === 'draw' && w.type === 'giveaway') {
        const names = [...st.entries.values()];
        if (!names.length) return json(res, 400, { error: 'Nobody has entered yet.' });
        st.winner = names[crypto.randomInt(names.length)];
      } else return json(res, 400, { error: 'Unknown action.' });
      toRoom(net.slug, { type: 'runtime', id: w.id, state: pubState(w, st) });
      return json(res, 200, { state: pubState(w, st) });
    }
  }
  return json(res, 404, { error: 'Not found' });
}

const server = http.createServer(async (req, res) => {
  baseHeaders(res);
  try {
    const u = new URL(req.url, 'http://localhost');
    let p;
    try { p = decodeURIComponent(u.pathname); } catch { return json(res, 400, { error: 'Bad path' }); }

    if (p.startsWith('/api/')) return await handleApi(req, res, p);
    if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'Method not allowed' });

    if (p === '/') return serveFile(req, res, 'index.html');
    if (p === '/guide') return serveFile(req, res, 'guide.html');
    if (/^\/n\/[^/]+\/?$/.test(p)) return serveFile(req, res, 'watch.html');
    if (/^\/studio\/[^/]+\/?$/.test(p)) return serveFile(req, res, 'studio.html');
    return serveFile(req, res, p.replace(/^\/+/, ''));
  } catch (e) {
    if (e && e.status) return json(res, e.status, { error: e.error });
    console.error(e);
    json(res, 500, { error: 'Server error' });
  }
});

// ---------- websocket signalling ----------
const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
server.on('upgrade', (req, socket, head) => {
  if (!req.url.startsWith('/ws')) return socket.destroy();
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
});

const send_ = (ws, obj) => {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
};
function toRoom(slug, obj) {
  const r = rooms.get(slug);
  if (!r) return;
  send_(r.broadcaster, obj);
  for (const v of r.viewers.values()) send_(v, obj);
}
const pushCount = (slug) => toRoom(slug, { type: 'count', n: viewerCount(slug) });

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.on('pong', () => (ws.isAlive = true));
  ws.role = null;
  ws.slug = null;
  ws.id = null;
  ws.lastChat = 0;
  ws.lastReact = 0;
  ws.lastAct = 0;

  ws.on('message', (raw) => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return; }
    if (!m || typeof m.type !== 'string') return;

    if (m.type === 'watch' && !ws.role) {
      const net = networks.get(m.slug);
      if (!net) return send_(ws, { type: 'error', error: 'Unknown network' });
      const r = room(net.slug);
      if (r.viewers.size >= MAX_VIEWERS) return send_(ws, { type: 'full', max: MAX_VIEWERS });
      ws.role = 'viewer';
      ws.slug = net.slug;
      ws.id = crypto.randomBytes(6).toString('hex');
      r.viewers.set(ws.id, ws);
      send_(ws, { type: 'hello', id: ws.id, live: !!r.broadcaster, title: r.title, startedAt: r.startedAt, runtime: runtimeFor(net) });
      if (r.broadcaster) send_(r.broadcaster, { type: 'viewer-joined', id: ws.id });
      pushCount(net.slug);
      return;
    }

    if (m.type === 'broadcast' && !ws.role) {
      const net = networks.get(m.slug);
      if (!net || !keyOk(net, m.key)) return send_(ws, { type: 'error', error: 'Wrong owner key' });
      const r = room(net.slug);
      if (r.broadcaster && r.broadcaster !== ws) {
        const old = r.broadcaster;
        old.role = null; // so its close handler doesn't tear down the new broadcast
        send_(old, { type: 'kicked' });
        try { old.close(); } catch {}
      }
      ws.role = 'broadcaster';
      ws.slug = net.slug;
      r.broadcaster = ws;
      r.title = clean(m.title, 80) || net.name + ' LIVE';
      r.startedAt = Date.now();
      send_(ws, { type: 'live-ok' });
      for (const v of r.viewers.values()) {
        send_(v, { type: 'live', title: r.title, startedAt: r.startedAt });
        send_(ws, { type: 'viewer-joined', id: v.id });
      }
      pushCount(net.slug);
      return;
    }

    if (!ws.role) return;
    const r = rooms.get(ws.slug);
    const net = networks.get(ws.slug);
    if (!r || !net) return;

    if (m.type === 'title' && ws.role === 'broadcaster') {
      r.title = clean(m.title, 80) || r.title;
      toRoom(ws.slug, { type: 'title', title: r.title });
      return;
    }

    if (m.type === 'signal') {
      if (ws.role === 'viewer' && r.broadcaster) send_(r.broadcaster, { type: 'signal', from: ws.id, data: m.data });
      else if (ws.role === 'broadcaster') {
        const v = r.viewers.get(m.to);
        if (v) send_(v, { type: 'signal', data: m.data });
      }
      return;
    }

    if (m.type === 'chat') {
      const now = Date.now();
      if (now - ws.lastChat < 700) return;
      ws.lastChat = now;
      const text = clean(m.text, 300);
      if (!text) return;
      const host = ws.role === 'broadcaster';
      const name = host ? net.name : clean(m.name, 20) || 'viewer';
      toRoom(ws.slug, { type: 'chat', name, text, host, t: now });
      return;
    }

    // ----- audience interaction -----
    if (m.type === 'react') {
      const now = Date.now();
      if (now - ws.lastReact < 150) return;
      ws.lastReact = now;
      if (!Schema.REACTIONS.includes(m.emoji) || !net.widgets.some((w) => w.type === 'reactions')) return;
      toRoom(ws.slug, { type: 'reaction', emoji: m.emoji });
      return;
    }

    if (m.type === 'vote' || m.type === 'enter') {
      const now = Date.now();
      if (now - ws.lastAct < 200) return;
      ws.lastAct = now;
      const w = net.widgets.find((x) => x.id === m.id);
      if (!w) return;
      const voter = clean(m.voter, 40) || ws.id;
      if (m.type === 'vote' && w.type === 'poll' && !w.cfg.closed && w.cfg.options.length >= 2) {
        const st = rtState(net, w);
        const idx = Number.isInteger(m.idx) ? m.idx : -1;
        if (idx < 0 || idx >= st.votes.length || st.voters.has(voter)) return;
        st.voters.set(voter, idx);
        st.votes[idx]++;
        queueRuntime(net.slug, w.id);
      } else if (m.type === 'enter' && w.type === 'giveaway' && w.cfg.open) {
        const st = rtState(net, w);
        if (st.entries.size >= 5000 && !st.entries.has(voter)) return;
        st.entries.set(voter, clean(m.name, 24) || 'guest');
        queueRuntime(net.slug, w.id);
      }
      return;
    }

    if (m.type === 'stop' && ws.role === 'broadcaster') endBroadcast(ws);
  });

  ws.on('close', () => {
    if (ws.role === 'broadcaster') endBroadcast(ws);
    else if (ws.role === 'viewer') {
      const r = rooms.get(ws.slug);
      if (r) {
        r.viewers.delete(ws.id);
        send_(r.broadcaster, { type: 'viewer-left', id: ws.id });
        pushCount(ws.slug);
      }
    }
  });
  ws.on('error', () => {});
});

function endBroadcast(ws) {
  const r = rooms.get(ws.slug);
  if (r && r.broadcaster === ws) {
    r.broadcaster = null;
    r.title = '';
    for (const v of r.viewers.values()) send_(v, { type: 'offline' });
    pushCount(ws.slug);
  }
  ws.role = null;
}

setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  }
}, 30000).unref();

if (require.main === module) {
  server.listen(PORT, () => console.log(`${SITE_NAME} running on http://localhost:${PORT}`));
}
module.exports = { server };
