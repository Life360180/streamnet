# StreamNet — host your own TV network

A small self-hosted streaming site. Anyone can:

- **Create a TV network** (name, tagline, colour, template) in seconds — no account needed
- **Go live** from their camera or by sharing their screen, from the Studio page
- **Add widgets** — 19 kinds, from polls and scoreboards to news tickers and giveaways
- **Start from a template** — 10 ready-made network styles
- **Turn on the Cable TV look** — channel numbers, CRT screen, TV-guide styling, channel surfing
- Share one public link (`/n/<network>`) that **anyone can watch**, no login

Viewers can open a network's page *before* it goes live; it switches on automatically when the broadcast starts.

## Run it

```bash
npm install      # one dependency: ws
npm start        # http://localhost:3000
```

Or just double-click **start.bat** (Windows) / **start.command** (Mac) — they install, start the server and open your browser.

Open `http://localhost:3000`, click **Start your network**, pick a template, save the owner key it shows you, then **Open studio → Go live**.

> **Open the site through the server (http://localhost:3000), not by double-clicking index.html** — pages opened as files show unstyled and can't load networks.

> **Camera / screen capture requires HTTPS** (or `localhost`). On a real domain, serve over HTTPS (Caddy or nginx + Let's Encrypt). WebSockets (`/ws`) must be proxied too.

### Settings (environment variables)

| Variable | Default | What it does |
|---|---|---|
| `PORT` | `3000` | Port to listen on |
| `SITE_NAME` | `StreamNet` | Your platform's name (shown in the header) |
| `DEFAULT_LOOK` | `modern` | Site-wide default look: `modern` or `cable` |
| `DATA_DIR` | `./data` | Where `networks.json` is stored |
| `MAX_VIEWERS_PER_STREAM` | `25` | Viewer cap per live stream (see "Scaling") |
| `MAX_NETWORKS` | `500` | Cap on networks that can be created |
| `TRUST_PROXY` | off | Set to `1` behind nginx/Caddy so rate limiting sees real IPs |
| `TURN_URL`, `TURN_USER`, `TURN_PASS` | none | TURN relay for viewers behind strict NATs |

## Widgets

Owners manage widgets in the Studio (**Widgets** tab): add, reorder, choose where each one shows (sidebar, under the video, or **on the video**), edit its settings with a live preview, then **Save & publish**. Published changes appear on viewers' screens instantly — no reload.

| Widget | What it does | Live controls in the studio |
|---|---|---|
| 🕒 Clock | Time in any time zone | |
| ⏳ Countdown | Count down to a date/time | |
| ⏱ Segment timer | Start / pause / reset timer | ▶ ⏸ reset |
| ▶️ Now & Next | What's on and what's next | update text |
| 📣 Announcement | Highlighted message (info / alert / celebration) | show / hide |
| 🔗 Links | Social and other links | |
| 💛 Support button | Tip / donate / merch link | |
| 🏷️ Sponsor | Sponsor or advertiser box | |
| ℹ️ About | Blurb about your network | |
| 🗓️ Program guide | Your schedule | |
| 📊 On-air stats | Live viewers + time on air | |
| 🗳️ Live poll | Viewers vote, bars move live | close / reset |
| 🏆 Scoreboard | Two teams, live scores | +/– buttons |
| 🔄 Rotating messages | Tips or headlines that cycle | |
| 🎁 Giveaway | Viewers enter, you draw a winner | draw / close / reset |
| 🎉 Reactions | Emoji that float up over the video | |
| 📰 News ticker | Scrolling crawl across the picture | add headlines |
| 🪧 Lower third | Name / caption bar on the video | show / hide, auto-hide |
| 🅲 Channel bug | Network name + channel number in a corner | |

Polls, giveaway entries and reactions are held in memory per stream (they reset if the server restarts). Everything else is saved in `data/networks.json`.

## Templates

Pick one when creating a network, or any time from the Studio's **Templates** tab (it replaces your widgets; your schedule stays): **Classic**, **24/7 Cable Channel**, **News Network**, **Sports Network**, **Gaming & Esports**, **Music & Radio TV**, **Community & Events**, **Shopping Channel**, **Talk Show**, **Minimal**. Templates are defined in `public/widget-schema.js` — add your own there.

## Cable TV look

A setting that makes the site feel like cable:

- **Channel numbers** for every network (owners can choose theirs in *Look & channel*)
- Picture inside a **CRT-style TV bezel** with scanlines, blue "TV guide" panels, gold headings
- **Channel surfing:** `↑` / `↓` (or the CH▲ ▼ buttons) flip channels with a burst of static and a green on-screen channel display
- **Channel guide:** press `G` while watching, or open `/guide`, for a Prevue-style listing of every channel — what's on now and what's next
- Overlays styled like on-screen graphics: channel bug, clock, crawl, lower thirds, scoreboard

Owners choose the *default* look for their network; every viewer can flip it with the **📺 Cable look** button (remembered in their browser). Site operators can make cable the default for everything with `DEFAULT_LOOK=cable`. Keyboard: `M` mute, `F` fullscreen, `Esc` close guide.

## How it works

```
Broadcaster (Studio) ──┐                         ┌── Viewer
   camera/screen       ├── WebSocket signalling ─┤
   WebRTC peer ────────┴── video goes directly ──┴── WebRTC peer
```

- The Node server handles the website, network data, widgets, live chat, polls/giveaways and WebRTC **signalling**.
- Video travels **peer-to-peer** from the broadcaster to each viewer over WebRTC.
- Each network has a secret **owner key** (stored hashed) for going live and editing. It's remembered in the owner's browser and can be pasted into the Studio on any device.
- All widget settings are validated on the server against the shared schema; text is always rendered as plain text and links must be `http(s)`.

## Scaling — please read

The broadcaster sends a separate video stream to every viewer, so capacity is limited by the **broadcaster's upload bandwidth**: roughly `viewers × bitrate` (10 viewers at "Medium" ≈ 18 Mbps up). Great for small and mid-size audiences, costs you no server bandwidth, but it won't handle hundreds of viewers per stream.

1. **Lower the quality** in the Studio (Low ≈ 0.8 Mbps per viewer) or lower `MAX_VIEWERS_PER_STREAM`.
2. **Add a TURN server** (e.g. [coturn](https://github.com/coturn/coturn)) and set `TURN_URL`/`TURN_USER`/`TURN_PASS`, or a few viewers on strict networks won't connect.
3. **For big audiences**, replace the peer-to-peer part with a media server (LiveKit, mediasoup, Janus) or an RTMP→HLS pipeline. Pages, widgets, templates, schedules and chat can stay as they are.

## Running a public platform

Letting strangers broadcast on your domain makes you responsible for what's shown. Before opening it widely, consider a terms page, a report/takedown path, an admin way to remove a network (today: delete its entry in `data/networks.json` and restart), and sign-in. Built-in protections are basic: rate-limited creation (5/hour/IP), capped sizes, hashed keys, schema validation of all widget data, and a strict Content-Security-Policy.

## Files

```
server.js              HTTP API, static files, WebSocket signalling, widget validation, poll/giveaway state
public/widget-schema.js  Widget types, fields and templates (shared by server and browser)
public/widgets.js        Widget renderers, live host, studio editor form, live controls
public/index.html        Home: browse, create network (template picker)
public/watch.html        Viewer page (/n/<network>) with channel surfing + guide overlay
public/studio.html       Studio (/studio/<network>): go live, widgets, templates, look, schedule
public/guide.html        Channel guide (/guide)
public/style.css, cable.css   Styles (cable.css = Cable TV look)
data/networks.json       Created on first run
```
