#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null; then
  echo "Node.js is required. Install it from https://nodejs.org and run this again."
  read -r -p "Press Enter to close"; exit 1
fi
[ -d node_modules ] || npm install
( sleep 2; open http://localhost:3000 2>/dev/null || xdg-open http://localhost:3000 2>/dev/null ) &
node server.js
